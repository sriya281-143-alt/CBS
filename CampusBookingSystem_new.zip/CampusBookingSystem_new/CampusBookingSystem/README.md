

## Demo login credentials (login is by EMAIL)

| Role    | Email             | Password    |
|---------|-------------------|-------------|
| Student | aisha@student.edu | student123  |
| Student | james@student.edu | student123  |
| Staff   | rahul@staff.edu   | staff123    |
| Admin   | safir@admin.edu   | admin123    |

Role is detected automatically after login — Students/Staff land on the Resource
Listing page, Admins land on the Admin Dashboard. "Forgot Password?" on the login
page looks the account up by email and shows the password back (plain-text CSV,
no hashing — kept intentionally simple for a student project).

## Project structure

```
model/       User, Resource, Booking        - plain flat classes, no inheritance
manager/     FileManager                    - generic CSV line read/write
             UserManager                    - users.csv + login/reset
             ResourceManager                - resources.csv + search/filter
             BookingManager                 - bookings.csv + validation rules
exception/   BookingException               - booking conflicts/invalid duration/unavailable
             UnauthorizedAccessException    - role/permission checks
util/        Session                        - one static field holding the logged-in user
controller/  LoginController, ResourcesController, BookingController, AdminDashboardController
```

Each Manager loads its CSV file in its constructor and saves immediately after every
change, so there's no shared "app context" object to keep in sync — each screen just
creates its own Manager instances and they all read/write the same files.


## OOP concept mapping (for your Part B report)

| Concept | Where |
|---|---|
| Encapsulation | All model fields are `private` with getters/setters |
| Custom exceptions | `BookingException`, `UnauthorizedAccessException` |
| Collections | `ArrayList`/`List` in every Manager class |
| File I/O | `FileManager` — `Files.readAllLines` / `Files.write` for CSV |
| GUI/Event handling | JavaFX FXML + `@FXML` handlers across all four controllers |


