package org.personal.campusbookingsystem.controller;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import org.personal.campusbookingsystem.exception.UnauthorizedAccessException;
import org.personal.campusbookingsystem.manager.BookingManager;
import org.personal.campusbookingsystem.manager.ResourceManager;
import org.personal.campusbookingsystem.model.Booking;
import org.personal.campusbookingsystem.model.Resource;
import org.personal.campusbookingsystem.model.User;
import org.personal.campusbookingsystem.util.Session;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/**
 * Controls the Resource Listing Form. Displays every campus resource as
 * a searchable/filterable card grid and lets the current user open the
 * Booking Form for any available resource. Also drives the "My
 * Bookings" table where the user can review and cancel their own
 * bookings.
 *
 * The resource cards are re-sized every time the window is resized (see
 * the scrollPane width listener at the bottom of initialize()) so the
 * row of cards always stretches edge-to-edge instead of leaving a gap
 * on the right.
 */
public class ResourcesController {

    private static final double CARD_MIN_WIDTH = 280;
    private static final double CARD_MAX_WIDTH = 400;
    private static final double CARD_GAP = 25;
    private static final double CONTENT_PADDING = 70; // 35px left + 35px right on the content VBox

    @FXML private VBox resourcesView;
    @FXML private VBox myBookingsView;
    @FXML private VBox profileView;

    @FXML private Button dashboardButton;
    @FXML private Button myBookingsButton;
    @FXML private Button profileButton;

    @FXML private Label topBarAvatarLabel;
    @FXML private Label topBarUserLabel;
    @FXML private Label topBarRoleLabel;

    @FXML private Label profileAvatarLabel;
    @FXML private Label profileNameLabel;
    @FXML private Label profileRoleLabel;
    @FXML private Label profileUserIdLabel;
    @FXML private Label profileEmailLabel;

    @FXML private Label availableCountLabel;
    @FXML private Label activeBookingsLabel;
    @FXML private Label pendingRequestsLabel;

    @FXML private TextField searchField;
    @FXML private ComboBox<String> typeFilterCombo;
    @FXML private ComboBox<String> statusFilterCombo;

    @FXML private ScrollPane scrollPane;
    @FXML private FlowPane resourceCardsPane;

    @FXML private TableView<Booking> myBookingsTable;
    @FXML private TableColumn<Booking, String> colBookingResource;
    @FXML private TableColumn<Booking, String> colBookingDate;
    @FXML private TableColumn<Booking, String> colBookingTime;
    @FXML private TableColumn<Booking, String> colBookingPurpose;
    @FXML private TableColumn<Booking, String> colBookingStatus;
    @FXML private TableColumn<Booking, Void> colBookingAction;

    // Managers load straight from the CSV files and write straight back to
    // them after every change, so there is no need for a shared "app context".
    private final ResourceManager resourceManager = new ResourceManager();
    private final BookingManager bookingManager = new BookingManager(resourceManager);

    private User currentUser;

    // Remembers whatever the card grid is currently showing (all resources, or a
    // filtered/searched subset) so it can be redrawn at a new card width on resize.
    private List<Resource> currentlyShownResources = new ArrayList<>();

    @FXML
    public void initialize() {
        currentUser = Session.getCurrentUser();
        if (currentUser == null) {
            return;
        }

        String initials = getInitials(currentUser.getName());
        topBarAvatarLabel.setText(initials);
        topBarUserLabel.setText(currentUser.getName());
        topBarRoleLabel.setText(currentUser.getRole());

        profileAvatarLabel.setText(initials);
        profileNameLabel.setText(currentUser.getName());
        profileRoleLabel.setText("Role: " + currentUser.getRole());
        profileUserIdLabel.setText("User ID: " + currentUser.getUserId());
        profileEmailLabel.setText("Email: " + currentUser.getEmail());

        setupFilterCombos();
        setupMyBookingsTable();
        renderResourceCards(resourceManager.getAll());
        refreshStats();
        setActiveNav(dashboardButton);

        // Whenever the window (and so the scroll pane's viewport) changes width,
        // redraw the cards at a new width so the row always fills edge-to-edge.
        scrollPane.viewportBoundsProperty().addListener((obs, oldBounds, newBounds) -> redrawCardsAtCurrentWidth());
    }

    /** Turns a name like "Aisha Shakya" into initials like "AS", used for the avatar badge. */
    private String getInitials(String name) {
        if (name == null || name.isBlank()) {
            return "?";
        }
        String[] words = name.trim().split("\\s+");
        String initials = "" + Character.toUpperCase(words[0].charAt(0));
        if (words.length > 1) {
            initials += Character.toUpperCase(words[1].charAt(0));
        }
        return initials;
    }

    /** Highlights the clicked sidebar button and un-highlights the other two. */
    private void setActiveNav(Button active) {
        dashboardButton.getStyleClass().setAll("sidebar-button");
        myBookingsButton.getStyleClass().setAll("sidebar-button");
        profileButton.getStyleClass().setAll("sidebar-button");
        active.getStyleClass().setAll("sidebar-button-selected");
    }

    private void setupFilterCombos() {
        ObservableList<String> types = FXCollections.observableArrayList("All Types");
        ObservableList<String> statuses = FXCollections.observableArrayList(
                "All Status", "AVAILABLE", "LIMITED", "OCCUPIED", "MAINTENANCE");

        for (Resource r : resourceManager.getAll()) {
            if (!types.contains(r.getResourceType())) {
                types.add(r.getResourceType());
            }
        }

        typeFilterCombo.setItems(types);
        statusFilterCombo.setItems(statuses);
        typeFilterCombo.getSelectionModel().selectFirst();
        statusFilterCombo.getSelectionModel().selectFirst();
    }

    private void setupMyBookingsTable() {
        colBookingResource.setCellValueFactory(data -> {
            Resource r = resourceManager.findById(data.getValue().getResourceId());
            return new SimpleStringProperty(r != null ? r.getName() : data.getValue().getResourceId());
        });
        colBookingDate.setCellValueFactory(data ->
                new SimpleStringProperty(data.getValue().getBookingDate().toString()));
        colBookingTime.setCellValueFactory(data ->
                new SimpleStringProperty(data.getValue().getTimeRangeText()));
        colBookingPurpose.setCellValueFactory(data ->
                new SimpleStringProperty(data.getValue().getPurpose()));
        colBookingStatus.setCellValueFactory(data ->
                new SimpleStringProperty(data.getValue().getStatus()));

        colBookingAction.setCellFactory(col -> new TableCell<>() {
            private final Button cancelBtn = new Button("Cancel");
            {
                cancelBtn.setOnAction(e -> {
                    Booking booking = getTableView().getItems().get(getIndex());
                    handleCancelBooking(booking);
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                    return;
                }
                Booking booking = getTableView().getItems().get(getIndex());
                boolean cancellable = booking.getStatus().equalsIgnoreCase("PENDING")
                        || booking.getStatus().equalsIgnoreCase("CONFIRMED");
                cancelBtn.setDisable(!cancellable);
                setGraphic(cancelBtn);
            }
        });

        refreshMyBookingsTable();
    }

    private void refreshMyBookingsTable() {
        List<Booking> mine = bookingManager.getBookingsForUser(currentUser.getUserId());
        myBookingsTable.setItems(FXCollections.observableArrayList(mine));
    }

    private void handleCancelBooking(Booking booking) {
        try {
            bookingManager.cancelBooking(booking.getBookingId(), currentUser);
            refreshMyBookingsTable();
            renderResourceCards(resourceManager.getAll());
            refreshStats();
        } catch (UnauthorizedAccessException e) {
            new Alert(Alert.AlertType.ERROR, e.getMessage()).showAndWait();
        }
    }

    private void refreshStats() {
        availableCountLabel.setText(String.valueOf(resourceManager.getAvailable().size()));

        List<Booking> mine = bookingManager.getBookingsForUser(currentUser.getUserId());
        long active = mine.stream().filter(b -> b.getStatus().equalsIgnoreCase("CONFIRMED")).count();
        long pending = mine.stream().filter(b -> b.getStatus().equalsIgnoreCase("PENDING")).count();

        activeBookingsLabel.setText(String.valueOf(active));
        pendingRequestsLabel.setText(String.valueOf(pending));
    }

    // ---------------------------------------------------------------
    // Resource card grid - sized dynamically so it always fills the
    // full row width, however wide the window currently is.
    // ---------------------------------------------------------------

    private void renderResourceCards(List<Resource> resources) {
        currentlyShownResources = resources;
        redrawCardsAtCurrentWidth();
    }

    private void redrawCardsAtCurrentWidth() {
        double cardWidth = computeCardWidth();
        resourceCardsPane.getChildren().clear();
        for (Resource r : currentlyShownResources) {
            resourceCardsPane.getChildren().add(buildResourceCard(r, cardWidth));
        }
    }

    /**
     * Works out how wide each card should be so that as many columns as
     * possible (at least CARD_MIN_WIDTH each) fit exactly into the
     * current viewport width, with no left-over space on the right.
     */
    private double computeCardWidth() {
        double viewportWidth = (scrollPane.getViewportBounds() != null)
                ? scrollPane.getViewportBounds().getWidth()
                : 1200;

        double usableWidth = viewportWidth - CONTENT_PADDING;
        if (usableWidth < CARD_MIN_WIDTH) {
            return CARD_MIN_WIDTH;
        }

        int columns = (int) ((usableWidth + CARD_GAP) / (CARD_MIN_WIDTH + CARD_GAP));
        if (columns < 1) {
            columns = 1;
        }

        double cardWidth = (usableWidth - (columns - 1) * CARD_GAP) / columns;
        return Math.min(cardWidth, CARD_MAX_WIDTH);
    }

    private VBox buildResourceCard(Resource r, double cardWidth) {
        VBox card = new VBox();
        card.getStyleClass().add("resource-card");
        card.setSpacing(10);
        card.setPrefWidth(cardWidth);
        card.setMinWidth(cardWidth);
        card.setMaxWidth(cardWidth);

        Label badge = new Label(r.getStatus());
        badge.getStyleClass().add(statusBadgeClass(r.getStatus()));

        Label title = new Label(r.getName());
        title.getStyleClass().add("resource-title");

        Label type = new Label("Type: " + r.getResourceType());
        Label capacity = new Label("👥 Up to " + r.getCapacity() + " people");

        Button bookBtn = new Button("Book Now");
        bookBtn.getStyleClass().add("book-button");
        bookBtn.setMaxWidth(Double.MAX_VALUE);
        bookBtn.setDisable(!r.isAvailable());
        bookBtn.setOnAction(e -> openBookingDialog(r));

        card.getChildren().addAll(badge, title, type, capacity, bookBtn);
        return card;
    }

    private String statusBadgeClass(String status) {
        if ("AVAILABLE".equalsIgnoreCase(status)) return "available-badge";
        if ("LIMITED".equalsIgnoreCase(status)) return "limited-badge";
        if ("OCCUPIED".equalsIgnoreCase(status)) return "occupied-badge";
        return "maintenance-badge";
    }

    private void openBookingDialog(Resource resource) {
        try {
            URL url = getClass().getResource("/org/personal/campusbookingsystem/booking/booking.fxml");
            FXMLLoader loader = new FXMLLoader(url);
            Parent root = loader.load();

            BookingController controller = loader.getController();
            controller.setUp(resource, currentUser, resourceManager, bookingManager);
            controller.setOnBookingCompleted(() -> {
                renderResourceCards(resourceManager.getAll());
                refreshStats();
                refreshMyBookingsTable();
            });

            Stage dialog = new Stage();
            dialog.initModality(Modality.APPLICATION_MODAL);
            dialog.setTitle("New Booking");
            Scene scene = new Scene(root);
            scene.getStylesheets().add(
                    getClass().getResource("/org/personal/campusbookingsystem/css/style.css").toExternalForm());
            dialog.setScene(scene);
            dialog.showAndWait();

        } catch (Exception e) {
            e.printStackTrace();
            new Alert(Alert.AlertType.ERROR, "Unable to open the booking form.").showAndWait();
        }
    }

    @FXML
    private void handleSearch() {
        String keyword = searchField.getText();
        String type = typeFilterCombo.getValue();
        String status = statusFilterCombo.getValue();
        renderResourceCards(resourceManager.search(keyword, type, status));
    }

    @FXML
    private void handleResetFilters() {
        searchField.clear();
        typeFilterCombo.getSelectionModel().selectFirst();
        statusFilterCombo.getSelectionModel().selectFirst();
        renderResourceCards(resourceManager.getAll());
    }

    @FXML
    private void showResourcesView() {
        resourcesView.setVisible(true);
        resourcesView.setManaged(true);
        myBookingsView.setVisible(false);
        myBookingsView.setManaged(false);
        profileView.setVisible(false);
        profileView.setManaged(false);
        setActiveNav(dashboardButton);
    }

    @FXML
    private void showMyBookingsView() {
        refreshMyBookingsTable();
        resourcesView.setVisible(false);
        resourcesView.setManaged(false);
        myBookingsView.setVisible(true);
        myBookingsView.setManaged(true);
        profileView.setVisible(false);
        profileView.setManaged(false);
        setActiveNav(myBookingsButton);
    }

    @FXML
    private void showProfile() {
        resourcesView.setVisible(false);
        resourcesView.setManaged(false);
        myBookingsView.setVisible(false);
        myBookingsView.setManaged(false);
        profileView.setVisible(true);
        profileView.setManaged(true);
        setActiveNav(profileButton);
    }

    @FXML
    private void handleLogout() {
        Session.clear();
        try {
            URL url = getClass().getResource("/org/personal/campusbookingsystem/login/login.fxml");
            Parent root = FXMLLoader.load(url);
            Stage stage = (Stage) dashboardButton.getScene().getWindow();
            Scene scene = new Scene(root);
            scene.getStylesheets().add(
                    getClass().getResource("/org/personal/campusbookingsystem/css/style.css").toExternalForm());
            stage.setScene(scene);
            stage.setTitle("Campus Booking System");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
