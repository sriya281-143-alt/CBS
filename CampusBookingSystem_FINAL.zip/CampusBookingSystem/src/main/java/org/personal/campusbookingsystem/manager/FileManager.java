package org.personal.campusbookingsystem.manager;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * Very simple helper class for reading and writing plain text/CSV
 * files. It just deals with raw lines of text - each Manager class
 * (UserManager, ResourceManager, BookingManager) is responsible for
 * turning its own objects into a comma-separated line and back again.
 * All files live inside a "data" folder next to the project.
 */
public class FileManager {

    private static final String DATA_DIR = "data";

    /** Reads every line of a CSV file. Returns an empty list if the file does not exist yet. */
    public static List<String> readLines(String fileName) {
        Path path = Path.of(DATA_DIR, fileName);

        if (!Files.exists(path)) {
            return new ArrayList<>();
        }

        try {
            return Files.readAllLines(path);
        } catch (IOException e) {
            System.out.println("Could not read " + fileName + ": " + e.getMessage());
            return new ArrayList<>();
        }
    }

    /** Overwrites a CSV file with the given lines, creating the data folder if needed. */
    public static void writeLines(String fileName, List<String> lines) {
        try {
            Files.createDirectories(Path.of(DATA_DIR));
            Path path = Path.of(DATA_DIR, fileName);
            Files.write(path, lines);
        } catch (IOException e) {
            System.out.println("Could not write " + fileName + ": " + e.getMessage());
        }
    }
}
