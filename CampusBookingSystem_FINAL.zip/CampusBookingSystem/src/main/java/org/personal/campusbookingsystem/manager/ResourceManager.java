package org.personal.campusbookingsystem.manager;

import org.personal.campusbookingsystem.exception.UnauthorizedAccessException;
import org.personal.campusbookingsystem.model.Resource;
import org.personal.campusbookingsystem.model.User;

import java.util.ArrayList;
import java.util.List;

/**
 * Holds all resources in memory (an ArrayList) and keeps them in sync
 * with resources.csv. Each row is: resourceId,name,resourceType,capacity,status
 */
public class ResourceManager {

    private static final String FILE_NAME = "resources.csv";

    private final List<Resource> resources = new ArrayList<>();

    public ResourceManager() {
        loadResources();
        if (resources.isEmpty()) {
            seedDemoResources();
            saveResources();
        }
    }

    private void loadResources() {
        resources.clear();
        for (String line : FileManager.readLines(FILE_NAME)) {
            if (line.isBlank()) {
                continue;
            }
            String[] parts = line.split(",", -1);
            if (parts.length < 5) {
                continue;
            }
            int capacity;
            try {
                capacity = Integer.parseInt(parts[3].trim());
            } catch (NumberFormatException e) {
                capacity = 0;
            }
            resources.add(new Resource(parts[0], parts[1], parts[2], capacity, parts[4]));
        }
    }

    public void saveResources() {
        List<String> lines = new ArrayList<>();
        for (Resource r : resources) {
            lines.add(r.getResourceId() + "," + r.getName() + "," + r.getResourceType() + "," + r.getCapacity() + "," + r.getStatus());
        }
        FileManager.writeLines(FILE_NAME, lines);
    }

    public void addResource(Resource resource, User actingUser) throws UnauthorizedAccessException {
        requireAdmin(actingUser);
        resources.add(resource);
        saveResources();
    }

    public boolean removeResource(String resourceId, User actingUser) throws UnauthorizedAccessException {
        requireAdmin(actingUser);
        boolean removed = resources.removeIf(r -> r.getResourceId().equalsIgnoreCase(resourceId));
        if (removed) {
            saveResources();
        }
        return removed;
    }

    /** Saves in-place edits made to an existing resource (name/capacity/type/status). */
    public void updateResource(User actingUser) throws UnauthorizedAccessException {
        requireAdmin(actingUser);
        saveResources();
    }

    /** Only Admins are allowed to add, edit, or delete resources. */
    private void requireAdmin(User actingUser) throws UnauthorizedAccessException {
        if (actingUser == null || !actingUser.isAdmin()) {
            throw new UnauthorizedAccessException("Only Admins can manage resources.");
        }
    }

    public Resource findById(String resourceId) {
        for (Resource r : resources) {
            if (r.getResourceId().equalsIgnoreCase(resourceId)) {
                return r;
            }
        }
        return null;
    }

    public List<Resource> getAll() {
        return resources;
    }

    public List<Resource> getAvailable() {
        List<Resource> available = new ArrayList<>();
        for (Resource r : resources) {
            if (r.isAvailable()) {
                available.add(r);
            }
        }
        return available;
    }

    public List<Resource> search(String keyword, String type, String status) {
        List<Resource> results = new ArrayList<>();
        for (Resource r : resources) {
            boolean matchesKeyword = keyword == null || keyword.isBlank()
                    || r.getName().toLowerCase().contains(keyword.toLowerCase());
            boolean matchesType = type == null || type.isBlank() || "All Types".equalsIgnoreCase(type)
                    || r.getResourceType().equalsIgnoreCase(type);
            boolean matchesStatus = status == null || status.isBlank() || "All Status".equalsIgnoreCase(status)
                    || r.getStatus().equalsIgnoreCase(status);

            if (matchesKeyword && matchesType && matchesStatus) {
                results.add(r);
            }
        }
        return results;
    }

    private void seedDemoResources() {
        resources.add(new Resource("R001", "Study Room A101", "Study Room", 8, "AVAILABLE"));
        resources.add(new Resource("R002", "Computer Lab", "Lab Equipment", 30, "AVAILABLE"));
        resources.add(new Resource("R003", "Single Study Room", "Study Room", 1, "LIMITED"));
        resources.add(new Resource("R004", "Seminar Room 101", "Event Space", 25, "MAINTENANCE"));
        resources.add(new Resource("R005", "Innovation Hub", "Event Space", 40, "AVAILABLE"));
        resources.add(new Resource("R006", "Research Lab", "Lab Equipment", 16, "OCCUPIED"));
        resources.add(new Resource("R007", "Portable Projector #1", "Lab Equipment", 1, "AVAILABLE"));
    }
}
