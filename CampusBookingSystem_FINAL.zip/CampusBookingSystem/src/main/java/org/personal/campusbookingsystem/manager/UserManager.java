package org.personal.campusbookingsystem.manager;

import org.personal.campusbookingsystem.model.User;

import java.util.ArrayList;
import java.util.List;

/**
 * Holds all users in memory (an ArrayList) and keeps them in sync with
 * users.csv. Each row is: userId,name,email,password,role
 *
 * Login is done by email (there is no separate username field once the
 * User class was flattened).
 */
public class UserManager {

    private static final String FILE_NAME = "users.csv";

    private final List<User> users = new ArrayList<>();

    public UserManager() {
        loadUsers();
        if (users.isEmpty()) {
            seedDemoUsers();
            saveUsers();
        }
    }

    private void loadUsers() {
        users.clear();
        for (String line : FileManager.readLines(FILE_NAME)) {
            if (line.isBlank()) {
                continue;
            }
            String[] parts = line.split(",", -1);
            if (parts.length < 5) {
                continue;
            }
            users.add(new User(parts[0], parts[1], parts[2], parts[3], parts[4]));
        }
    }

    public void saveUsers() {
        List<String> lines = new ArrayList<>();
        for (User u : users) {
            lines.add(u.getUserId() + "," + u.getName() + "," + u.getEmail() + "," + u.getPassword() + "," + u.getRole());
        }
        FileManager.writeLines(FILE_NAME, lines);
    }

    public User login(String email, String password) {
        User user = findByEmail(email);
        if (user != null && user.getPassword().equals(password)) {
            return user;
        }
        return null;
    }

    public User findByEmail(String email) {
        for (User u : users) {
            if (u.getEmail().equalsIgnoreCase(email)) {
                return u;
            }
        }
        return null;
    }

    public void addUser(User user) {
        users.add(user);
        saveUsers();
    }

    public List<User> getAllUsers() {
        return users;
    }

    private void seedDemoUsers() {
        users.add(new User("U001", "Aisha Shakya", "aisha@student.edu", "student123", "STUDENT"));
        users.add(new User("U002", "James Olen", "james@student.edu", "student123", "STUDENT"));
        users.add(new User("U003", "Rahul Patel", "rahul@staff.edu", "staff123", "STAFF"));
        users.add(new User("U004", "Safir Gautam", "safir@admin.edu", "admin123", "ADMIN"));
    }
}
