package org.personal.campusbookingsystem.exception;

/**
 * A single custom checked exception used for anything that can go
 * wrong while creating/managing a booking: the resource is already
 * booked at that time (double-booking), the resource is unavailable,
 * or the requested duration is invalid (e.g. end time before start
 * time, or longer than the allowed maximum).
 */
public class BookingException extends Exception {

    public BookingException(String message) {
        super(message);
    }
}
