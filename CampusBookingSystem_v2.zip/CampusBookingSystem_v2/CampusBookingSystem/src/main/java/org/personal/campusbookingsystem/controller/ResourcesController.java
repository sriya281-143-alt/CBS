package org.personal.campusbookingsystem.controller;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import org.personal.campusbookingsystem.exception.UnauthorizedAccessException;
import org.personal.campusbookingsystem.manager.BookingManager;
import org.personal.campusbookingsystem.manager.ResourceManager;
import org.personal.campusbookingsystem.model.Booking;
import org.personal.campusbookingsystem.model.Resource;
import org.personal.campusbookingsystem.model.User;
import org.personal.campusbookingsystem.util.Session;

import java.net.URL;
import java.util.List;

/**
 * Controls the Resource Listing Form. Displays every campus resource as
 * a searchable/filterable card grid (wrapped in a FlowPane so it
 * reflows nicely when the window is resized/maximized) and lets the
 * current user open the Booking Form for any available resource. Also
 * drives the "My Bookings" table where the user can review and cancel
 * their own bookings.
 */
public class ResourcesController {

    @FXML private VBox resourcesView;
    @FXML private VBox myBookingsView;
    @FXML private VBox profileView;

    @FXML private Button dashboardButton;
    @FXML private Button myBookingsButton;
    @FXML private Button profileButton;

    @FXML private Label sidebarUserNameLabel;
    @FXML private Label sidebarUserRoleLabel;
    @FXML private Label topBarAvatarLabel;
    @FXML private Label topBarUserLabel;

    @FXML private Label profileAvatarLabel;
    @FXML private Label profileNameLabel;
    @FXML private Label profileRoleLabel;
    @FXML private Label profileUserIdLabel;
    @FXML private Label profileEmailLabel;

    @FXML private Label availableCountLabel;
    @FXML private Label activeBookingsLabel;
    @FXML private Label pendingRequestsLabel;

    @FXML private TextField searchField;
    @FXML private ComboBox<String> typeFilterCombo;
    @FXML private ComboBox<String> statusFilterCombo;

    @FXML private FlowPane resourceCardsPane;

    @FXML private TableView<Booking> myBookingsTable;
    @FXML private TableColumn<Booking, String> colBookingResource;
    @FXML private TableColumn<Booking, String> colBookingDate;
    @FXML private TableColumn<Booking, String> colBookingTime;
    @FXML private TableColumn<Booking, String> colBookingPurpose;
    @FXML private TableColumn<Booking, String> colBookingStatus;
    @FXML private TableColumn<Booking, Void> colBookingAction;

    // Managers load straight from the CSV files and write straight back to
    // them after every change, so there is no need for a shared "app context".
    private final ResourceManager resourceManager = new ResourceManager();
    private final BookingManager bookingManager = new BookingManager(resourceManager);

    private User currentUser;

    @FXML
    public void initialize() {
        currentUser = Session.getCurrentUser();
        if (currentUser == null) {
            return;
        }

        sidebarUserNameLabel.setText(currentUser.getName());
        sidebarUserRoleLabel.setText(currentUser.getRole());

        String initials = getInitials(currentUser.getName());
        topBarAvatarLabel.setText(initials);
        topBarUserLabel.setText(currentUser.getName());

        profileAvatarLabel.setText(initials);
        profileNameLabel.setText(currentUser.getName());
        profileRoleLabel.setText("Role: " + currentUser.getRole());
        profileUserIdLabel.setText("User ID: " + currentUser.getUserId());
        profileEmailLabel.setText("Email: " + currentUser.getEmail());

        setupFilterCombos();
        setupMyBookingsTable();
        renderResourceCards(resourceManager.getAll());
        refreshStats();
        setActiveNav(dashboardButton);
    }

    /** Turns a name like "Aisha Shakya" into initials like "AS", used for the avatar badge. */
    private String getInitials(String name) {
        if (name == null || name.isBlank()) {
            return "?";
        }
        String[] words = name.trim().split("\\s+");
        String initials = "" + Character.toUpperCase(words[0].charAt(0));
        if (words.length > 1) {
            initials += Character.toUpperCase(words[1].charAt(0));
        }
        return initials;
    }

    /** Highlights the clicked sidebar button and un-highlights the other two. */
    private void setActiveNav(Button active) {
        dashboardButton.getStyleClass().setAll("sidebar-button");
        myBookingsButton.getStyleClass().setAll("sidebar-button");
        profileButton.getStyleClass().setAll("sidebar-button");
        active.getStyleClass().setAll("sidebar-button-selected");
    }

    private void setupFilterCombos() {
        ObservableList<String> types = FXCollections.observableArrayList("All Types");
        ObservableList<String> statuses = FXCollections.observableArrayList(
                "All Status", "AVAILABLE", "LIMITED", "OCCUPIED", "MAINTENANCE");

        for (Resource r : resourceManager.getAll()) {
            if (!types.contains(r.getResourceType())) {
                types.add(r.getResourceType());
            }
        }

        typeFilterCombo.setItems(types);
        statusFilterCombo.setItems(statuses);
        typeFilterCombo.getSelectionModel().selectFirst();
        statusFilterCombo.getSelectionModel().selectFirst();
    }

    private void setupMyBookingsTable() {
        colBookingResource.setCellValueFactory(data -> {
            Resource r = resourceManager.findById(data.getValue().getResourceId());
            return new SimpleStringProperty(r != null ? r.getName() : data.getValue().getResourceId());
        });
        colBookingDate.setCellValueFactory(data ->
                new SimpleStringProperty(data.getValue().getBookingDate().toString()));
        colBookingTime.setCellValueFactory(data ->
                new SimpleStringProperty(data.getValue().getTimeRangeText()));
        colBookingPurpose.setCellValueFactory(data ->
                new SimpleStringProperty(data.getValue().getPurpose()));
        colBookingStatus.setCellValueFactory(data ->
                new SimpleStringProperty(data.getValue().getStatus()));

        colBookingAction.setCellFactory(col -> new TableCell<>() {
            private final Button cancelBtn = new Button("Cancel");
            {
                cancelBtn.setOnAction(e -> {
                    Booking booking = getTableView().getItems().get(getIndex());
                    handleCancelBooking(booking);
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                    return;
                }
                Booking booking = getTableView().getItems().get(getIndex());
                boolean cancellable = booking.getStatus().equalsIgnoreCase("PENDING")
                        || booking.getStatus().equalsIgnoreCase("CONFIRMED");
                cancelBtn.setDisable(!cancellable);
                setGraphic(cancelBtn);
            }
        });

        refreshMyBookingsTable();
    }

    private void refreshMyBookingsTable() {
        List<Booking> mine = bookingManager.getBookingsForUser(currentUser.getUserId());
        myBookingsTable.setItems(FXCollections.observableArrayList(mine));
    }

    private void handleCancelBooking(Booking booking) {
        try {
            bookingManager.cancelBooking(booking.getBookingId(), currentUser);
            refreshMyBookingsTable();
            renderResourceCards(resourceManager.getAll());
            refreshStats();
        } catch (UnauthorizedAccessException e) {
            new Alert(Alert.AlertType.ERROR, e.getMessage()).showAndWait();
        }
    }

    private void refreshStats() {
        availableCountLabel.setText(String.valueOf(resourceManager.getAvailable().size()));

        List<Booking> mine = bookingManager.getBookingsForUser(currentUser.getUserId());
        long active = mine.stream().filter(b -> b.getStatus().equalsIgnoreCase("CONFIRMED")).count();
        long pending = mine.stream().filter(b -> b.getStatus().equalsIgnoreCase("PENDING")).count();

        activeBookingsLabel.setText(String.valueOf(active));
        pendingRequestsLabel.setText(String.valueOf(pending));
    }

    private void renderResourceCards(List<Resource> resources) {
        resourceCardsPane.getChildren().clear();
        for (Resource r : resources) {
            resourceCardsPane.getChildren().add(buildResourceCard(r));
        }
    }

    private VBox buildResourceCard(Resource r) {
        VBox card = new VBox();
        card.getStyleClass().add("resource-card");
        card.setSpacing(10);

        Label badge = new Label(r.getStatus());
        badge.getStyleClass().add(statusBadgeClass(r.getStatus()));

        Label title = new Label(r.getName());
        title.getStyleClass().add("resource-title");

        Label type = new Label("Type: " + r.getResourceType());
        Label capacity = new Label("👥 Up to " + r.getCapacity() + " people");

        Button bookBtn = new Button("Book Now");
        bookBtn.getStyleClass().add("book-button");
        bookBtn.setDisable(!r.isAvailable());
        bookBtn.setOnAction(e -> openBookingDialog(r));

        card.getChildren().addAll(badge, title, type, capacity, bookBtn);
        return card;
    }

    private String statusBadgeClass(String status) {
        if ("AVAILABLE".equalsIgnoreCase(status)) return "available-badge";
        if ("LIMITED".equalsIgnoreCase(status)) return "limited-badge";
        if ("OCCUPIED".equalsIgnoreCase(status)) return "occupied-badge";
        return "maintenance-badge";
    }

    private void openBookingDialog(Resource resource) {
        try {
            URL url = getClass().getResource("/org/personal/campusbookingsystem/booking/booking.fxml");
            FXMLLoader loader = new FXMLLoader(url);
            Parent root = loader.load();

            BookingController controller = loader.getController();
            controller.setUp(resource, currentUser, resourceManager, bookingManager);
            controller.setOnBookingCompleted(() -> {
                renderResourceCards(resourceManager.getAll());
                refreshStats();
                refreshMyBookingsTable();
            });

            Stage dialog = new Stage();
            dialog.initModality(Modality.APPLICATION_MODAL);
            dialog.setTitle("New Booking");
            Scene scene = new Scene(root);
            scene.getStylesheets().add(
                    getClass().getResource("/org/personal/campusbookingsystem/css/style.css").toExternalForm());
            dialog.setScene(scene);
            dialog.showAndWait();

        } catch (Exception e) {
            e.printStackTrace();
            new Alert(Alert.AlertType.ERROR, "Unable to open the booking form.").showAndWait();
        }
    }

    @FXML
    private void handleSearch() {
        String keyword = searchField.getText();
        String type = typeFilterCombo.getValue();
        String status = statusFilterCombo.getValue();
        renderResourceCards(resourceManager.search(keyword, type, status));
    }

    @FXML
    private void handleResetFilters() {
        searchField.clear();
        typeFilterCombo.getSelectionModel().selectFirst();
        statusFilterCombo.getSelectionModel().selectFirst();
        renderResourceCards(resourceManager.getAll());
    }

    @FXML
    private void showResourcesView() {
        resourcesView.setVisible(true);
        resourcesView.setManaged(true);
        myBookingsView.setVisible(false);
        myBookingsView.setManaged(false);
        profileView.setVisible(false);
        profileView.setManaged(false);
        setActiveNav(dashboardButton);
    }

    @FXML
    private void showMyBookingsView() {
        refreshMyBookingsTable();
        resourcesView.setVisible(false);
        resourcesView.setManaged(false);
        myBookingsView.setVisible(true);
        myBookingsView.setManaged(true);
        profileView.setVisible(false);
        profileView.setManaged(false);
        setActiveNav(myBookingsButton);
    }

    @FXML
    private void showProfile() {
        resourcesView.setVisible(false);
        resourcesView.setManaged(false);
        myBookingsView.setVisible(false);
        myBookingsView.setManaged(false);
        profileView.setVisible(true);
        profileView.setManaged(true);
        setActiveNav(profileButton);
    }

    @FXML
    private void handleLogout() {
        Session.clear();
        try {
            URL url = getClass().getResource("/org/personal/campusbookingsystem/login/login.fxml");
            Parent root = FXMLLoader.load(url);
            Stage stage = (Stage) sidebarUserNameLabel.getScene().getWindow();
            Scene scene = new Scene(root);
            scene.getStylesheets().add(
                    getClass().getResource("/org/personal/campusbookingsystem/css/style.css").toExternalForm());
            stage.setScene(scene);
            stage.setTitle("Campus Booking System");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
