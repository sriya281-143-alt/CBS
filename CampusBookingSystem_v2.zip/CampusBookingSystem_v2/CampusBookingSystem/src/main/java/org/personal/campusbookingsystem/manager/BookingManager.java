package org.personal.campusbookingsystem.manager;

import org.personal.campusbookingsystem.exception.BookingException;
import org.personal.campusbookingsystem.exception.UnauthorizedAccessException;
import org.personal.campusbookingsystem.model.Booking;
import org.personal.campusbookingsystem.model.Resource;
import org.personal.campusbookingsystem.model.User;

import java.time.Duration;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/**
 * Holds all bookings in memory (an ArrayList) and keeps them in sync
 * with bookings.csv. Also contains the booking validation rules: no
 * double-booking, no invalid durations, and role checks for approving
 * or cancelling a booking.
 *
 * Each row is:
 * bookingId,userId,creatorName,resourceId,bookingDate,startTime,endTime,purpose,status
 */
public class BookingManager {

    private static final String FILE_NAME = "bookings.csv";
    private static final int MAX_DURATION_HOURS = 3;
    private static final DateTimeFormatter DATE_FMT = DateTimeFormatter.ISO_LOCAL_DATE;
    private static final DateTimeFormatter TIME_FMT = DateTimeFormatter.ofPattern("HH:mm");

    private final List<Booking> bookings = new ArrayList<>();
    private final ResourceManager resourceManager;
    private int nextIdNumber = 1;

    public BookingManager(ResourceManager resourceManager) {
        this.resourceManager = resourceManager;
        loadBookings();
    }

    private void loadBookings() {
        bookings.clear();
        for (String line : FileManager.readLines(FILE_NAME)) {
            if (line.isBlank()) {
                continue;
            }
            String[] p = line.split(",", -1);
            if (p.length < 9) {
                continue;
            }
            Booking b = new Booking(
                    p[0], p[1], p[2], p[3],
                    java.time.LocalDate.parse(p[4], DATE_FMT),
                    java.time.LocalTime.parse(p[5], TIME_FMT),
                    java.time.LocalTime.parse(p[6], TIME_FMT),
                    p[7].replace(";", ","),
                    p[8]);
            bookings.add(b);

            int number = parseIdNumber(b.getBookingId());
            if (number >= nextIdNumber) {
                nextIdNumber = number + 1;
            }
        }
    }

    private int parseIdNumber(String bookingId) {
        try {
            return Integer.parseInt(bookingId.replaceAll("\\D", ""));
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    public void saveBookings() {
        List<String> lines = new ArrayList<>();
        for (Booking b : bookings) {
            // commas are not allowed inside a plain CSV field, so replace them in free-text purpose
            String safePurpose = b.getPurpose() == null ? "" : b.getPurpose().replace(",", ";");
            lines.add(String.join(",",
                    b.getBookingId(), b.getUserId(), b.getCreatorName(), b.getResourceId(),
                    b.getBookingDate().format(DATE_FMT),
                    b.getStartTime().format(TIME_FMT),
                    b.getEndTime().format(TIME_FMT),
                    safePurpose, b.getStatus()));
        }
        FileManager.writeLines(FILE_NAME, lines);
    }

    public Booking createBooking(Booking booking, User actingUser) throws BookingException {

        // 1) Duration validation
        if (!booking.getEndTime().isAfter(booking.getStartTime())) {
            throw new BookingException("End time must be after start time.");
        }
        Duration duration = Duration.between(booking.getStartTime(), booking.getEndTime());
        if (duration.toMinutes() > MAX_DURATION_HOURS * 60) {
            throw new BookingException("Booking duration cannot exceed " + MAX_DURATION_HOURS + " hours.");
        }

        // 2) Resource availability
        Resource resource = resourceManager.findById(booking.getResourceId());
        if (resource == null || !resource.isAvailable()) {
            throw new BookingException("This resource is not available right now.");
        }

        // 3) Double-booking / time-slot conflict check
        for (Booking existing : bookings) {
            boolean sameResource = existing.getResourceId().equals(booking.getResourceId());
            boolean sameDate = existing.getBookingDate().equals(booking.getBookingDate());
            boolean active = !existing.getStatus().equalsIgnoreCase("CANCELLED")
                    && !existing.getStatus().equalsIgnoreCase("REJECTED");
            boolean overlaps = booking.getStartTime().isBefore(existing.getEndTime())
                    && existing.getStartTime().isBefore(booking.getEndTime());

            if (sameResource && sameDate && active && overlaps) {
                throw new BookingException("This resource is already booked for the selected time slot.");
            }
        }

        // 4) Assign ID + initial status - students need Staff/Admin approval, Staff/Admin are auto-confirmed
        booking.setBookingId("BK" + String.format("%04d", nextIdNumber++));

        if (actingUser != null && actingUser.isStudent()) {
            booking.setStatus("PENDING");
        } else {
            booking.setStatus("CONFIRMED");
            resource.setStatus("OCCUPIED");
            resourceManager.saveResources();
        }

        bookings.add(booking);
        saveBookings();
        return booking;
    }

    public List<Booking> getAllBookings() {
        return bookings;
    }

    public List<Booking> getBookingsForUser(String userId) {
        List<Booking> mine = new ArrayList<>();
        for (Booking b : bookings) {
            if (b.getUserId().equals(userId)) {
                mine.add(b);
            }
        }
        return mine;
    }

    public Booking findBookingById(String bookingId) {
        for (Booking b : bookings) {
            if (b.getBookingId().equalsIgnoreCase(bookingId)) {
                return b;
            }
        }
        return null;
    }

    public void updateBookingStatus(String bookingId, String newStatus, User actingUser) throws UnauthorizedAccessException {
        if (actingUser == null || actingUser.isStudent()) {
            throw new UnauthorizedAccessException("Only Staff or Admin can approve/reject bookings.");
        }
        Booking booking = findBookingById(bookingId);
        if (booking == null) {
            return;
        }
        booking.setStatus(newStatus);

        Resource resource = resourceManager.findById(booking.getResourceId());
        if (resource != null) {
            if ("CONFIRMED".equalsIgnoreCase(newStatus)) {
                resource.setStatus("OCCUPIED");
            } else if ("REJECTED".equalsIgnoreCase(newStatus)) {
                resource.setStatus("AVAILABLE");
            }
            resourceManager.saveResources();
        }

        saveBookings();
    }

    public void cancelBooking(String bookingId, User actingUser) throws UnauthorizedAccessException {
        Booking booking = findBookingById(bookingId);
        if (booking == null) {
            return;
        }

        boolean isOwner = actingUser != null && booking.getUserId().equals(actingUser.getUserId());
        boolean isAdmin = actingUser != null && actingUser.isAdmin();

        if (!isOwner && !isAdmin) {
            throw new UnauthorizedAccessException("You do not have permission to cancel this booking.");
        }

        booking.setStatus("CANCELLED");

        Resource resource = resourceManager.findById(booking.getResourceId());
        if (resource != null) {
            resource.setStatus("AVAILABLE");
            resourceManager.saveResources();
        }

        saveBookings();
    }
}
