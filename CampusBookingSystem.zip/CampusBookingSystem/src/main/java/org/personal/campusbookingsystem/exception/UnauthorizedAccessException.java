package org.personal.campusbookingsystem.exception;

/**
 * Thrown when a user attempts to perform an action beyond their
 * assigned role/permission level (e.g. a Student trying to approve a
 * booking, or manage resources that only Admins may touch).
 */
public class UnauthorizedAccessException extends BookingException {

    public UnauthorizedAccessException(String message) {
        super(message);
    }
}
