package org.personal.campusbookingsystem.util;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

/**
 * Generic (utility) class responsible for ALL file input/output in the
 * system: binary object serialization for domain data (users,
 * resources, bookings) and plain text appending for the log file.
 * Centralising I/O here keeps the rest of the codebase free of
 * try/catch boilerplate and matches the "File Management module"
 * described in the analysis and design report.
 */
public final class FileIOHandler {

    public static final Path DATA_DIR = Path.of("data");

    private FileIOHandler() {
    }

    /** Serializes any Serializable object (typically a List) to the given file name inside /data. */
    public static void writeObjectToFile(String fileName, Object object) {
        try {
            Files.createDirectories(DATA_DIR);
            try (ObjectOutputStream out = new ObjectOutputStream(
                    new BufferedOutputStream(new FileOutputStream(DATA_DIR.resolve(fileName).toFile())))) {
                out.writeObject(object);
            }
        } catch (IOException e) {
            System.err.println("Failed to write " + fileName + ": " + e.getMessage());
        }
    }

    /** Reads a previously serialized object back, or null if the file does not exist / cannot be read. */
    @SuppressWarnings("unchecked")
    public static <T> T readObjectFromFile(String fileName) {
        Path path = DATA_DIR.resolve(fileName);
        if (!Files.exists(path)) {
            return null;
        }
        try (ObjectInputStream in = new ObjectInputStream(
                new BufferedInputStream(new FileInputStream(path.toFile())))) {
            return (T) in.readObject();
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Failed to read " + fileName + ": " + e.getMessage());
            return null;
        }
    }

    /** Appends a single line of text to a log file inside /data, creating it if necessary. */
    public static void appendTextToFile(String fileName, String line) {
        try {
            Files.createDirectories(DATA_DIR);
            try (BufferedWriter writer = new BufferedWriter(
                    new FileWriter(DATA_DIR.resolve(fileName).toFile(), true))) {
                writer.write(line);
                writer.newLine();
            }
        } catch (IOException e) {
            System.err.println("Failed to append to " + fileName + ": " + e.getMessage());
        }
    }

    /** Reads every line of a text log file. Returns an empty list if the file is missing. */
    public static List<String> readLogsFromFile(String fileName) {
        Path path = DATA_DIR.resolve(fileName);
        if (!Files.exists(path)) {
            return List.of();
        }
        try {
            return Files.readAllLines(path);
        } catch (IOException e) {
            System.err.println("Failed to read " + fileName + ": " + e.getMessage());
            return List.of();
        }
    }
}
