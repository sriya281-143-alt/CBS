package org.personal.campusbookingsystem.model;

import java.io.Serializable;

/**
 * Abstract superclass for every bookable campus resource. Demonstrates
 * ABSTRACTION: common attributes (id, name, location, capacity, status)
 * live here, while resource-type-specific behaviour lives in the
 * concrete subclasses (StudyRoom, LabEquipment, EventSpace).
 */
public abstract class Resource implements Serializable {

    private static final long serialVersionUID = 1L;

    private String resourceId;
    private String resourceName;
    private String location;
    private int capacity;
    private ResourceStatus status;

    protected Resource() {
    }

    protected Resource(String resourceId, String resourceName, String location,
                        int capacity, ResourceStatus status) {
        this.resourceId = resourceId;
        this.resourceName = resourceName;
        this.location = location;
        this.capacity = capacity;
        this.status = status;
    }

    /** Human readable resource type label, overridden by every subclass (POLYMORPHISM). */
    public abstract String getResourceType();

    /** True while the resource can still accept new bookings. */
    public boolean checkAvailability() {
        return status == ResourceStatus.AVAILABLE || status == ResourceStatus.LIMITED;
    }

    public void updateStatus(ResourceStatus newStatus) {
        this.status = newStatus;
    }

    public String getResourceId() {
        return resourceId;
    }

    public void setResourceId(String resourceId) {
        this.resourceId = resourceId;
    }

    public String getResourceName() {
        return resourceName;
    }

    public void setResourceName(String resourceName) {
        this.resourceName = resourceName;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public ResourceStatus getStatus() {
        return status;
    }

    public void setStatus(ResourceStatus status) {
        this.status = status;
    }

    public boolean isAvailable() {
        return checkAvailability();
    }

    @Override
    public String toString() {
        return resourceName + " (" + getResourceType() + ")";
    }
}
