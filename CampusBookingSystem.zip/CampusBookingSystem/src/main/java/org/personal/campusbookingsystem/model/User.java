package org.personal.campusbookingsystem.model;

import java.io.Serializable;

/**
 * Abstract superclass representing any authenticated user of the system.
 * Demonstrates ABSTRACTION and forms the base of the User inheritance
 * hierarchy (Student, Staff, Admin) shown in the class diagram.
 *
 * The password field always stores an ENCODED value (see
 * {@link org.personal.campusbookingsystem.util.PasswordUtil}); plain text
 * passwords are never persisted, satisfying the assignment's data
 * privacy requirement.
 */
public abstract class User implements Serializable {

    private static final long serialVersionUID = 1L;

    private String userId;
    private String username;
    private String password; // encoded, never plain text
    private String name;
    private String email;

    protected User() {
    }

    protected User(String userId, String username, String password, String name, String email) {
        this.userId = userId;
        this.username = username;
        this.password = password;
        this.name = name;
        this.email = email;
    }

    /**
     * Validates the supplied plain-text password against the stored
     * encoded password. Demonstrates behaviour declared on the abstract
     * User class in the UML class diagram (+login()).
     */
    public boolean login(String plainTextPassword) {
        return org.personal.campusbookingsystem.util.PasswordUtil.matches(plainTextPassword, this.password);
    }

    /**
     * Every concrete subclass must report its own role.
     * Demonstrates POLYMORPHISM: the actual role returned depends on the
     * runtime type of the object (Student/Staff/Admin).
     */
    public abstract Role getRole();

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String toString() {
        return name + " (" + getRole() + ")";
    }
}
