package org.personal.campusbookingsystem.util;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/** A single audit-trail entry recorded by {@link SystemLogger}. */
public class LogEntry implements Serializable {

    private static final long serialVersionUID = 1L;
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private final String logId;
    private final LocalDateTime timestamp;
    private final String userId;
    private final String actionType;
    private final String description;

    public LogEntry(String logId, String userId, String actionType, String description) {
        this.logId = logId;
        this.timestamp = LocalDateTime.now();
        this.userId = userId;
        this.actionType = actionType;
        this.description = description;
    }

    public String toLogLine() {
        return String.format("[%s] %s | user=%s | action=%s | %s",
                timestamp.format(FMT), logId, userId, actionType, description);
    }

    public String getLogId() {
        return logId;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public String getUserId() {
        return userId;
    }

    public String getActionType() {
        return actionType;
    }

    public String getDescription() {
        return description;
    }
}
