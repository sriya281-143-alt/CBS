package org.personal.campusbookingsystem.util;

import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Simple singleton-style logging facility. Every significant system
 * event (login, booking created/approved/rejected/cancelled, resource
 * change) is written to data/system_logs.txt via FileIOHandler so that
 * Admins can review activity through "View System Logs".
 */
public final class SystemLogger {

    private static final String LOG_FILE = "system_logs.txt";
    private static final AtomicInteger COUNTER = new AtomicInteger(1);

    private SystemLogger() {
    }

    public static void logEvent(String userId, String actionType, String description) {
        LogEntry entry = new LogEntry("LOG" + String.format("%04d", COUNTER.getAndIncrement()), userId, actionType, description);
        FileIOHandler.appendTextToFile(LOG_FILE, entry.toLogLine());
    }

    public static void logError(String userId, String actionType, String errorMessage) {
        logEvent(userId, actionType, "ERROR: " + errorMessage);
    }

    public static List<String> readLogsFromFile() {
        return FileIOHandler.readLogsFromFile(LOG_FILE);
    }
}
