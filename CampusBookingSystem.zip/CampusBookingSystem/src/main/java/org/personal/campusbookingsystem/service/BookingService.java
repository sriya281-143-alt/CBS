package org.personal.campusbookingsystem.service;

import org.personal.campusbookingsystem.exception.InvalidBookingDurationException;
import org.personal.campusbookingsystem.exception.ResourceUnavailableException;
import org.personal.campusbookingsystem.exception.UnauthorizedAccessException;
import org.personal.campusbookingsystem.model.Booking;
import org.personal.campusbookingsystem.model.BookingStatus;
import org.personal.campusbookingsystem.model.User;

import java.util.List;

public interface BookingService {

    /** Validates and creates a new booking. Status is decided automatically (PENDING for students). */
    Booking createBooking(Booking booking) throws ResourceUnavailableException, InvalidBookingDurationException;

    List<Booking> getAllBookings();

    List<Booking> getBookingsForUser(String userId);

    Booking findBookingById(String bookingId);

    boolean removeBooking(String bookingId);

    /** Staff/Admin only: approves or rejects a PENDING booking. */
    void updateBookingStatus(String bookingId, BookingStatus newStatus, User actingUser) throws UnauthorizedAccessException;

    /** Cancels a booking; students/staff may only cancel their own, Admins may cancel any. */
    void cancelBooking(String bookingId, User actingUser) throws UnauthorizedAccessException;
}
