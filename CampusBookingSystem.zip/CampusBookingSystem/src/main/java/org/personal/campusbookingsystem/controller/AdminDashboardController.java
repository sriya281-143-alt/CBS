package org.personal.campusbookingsystem.controller;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import org.personal.campusbookingsystem.AppContext;
import org.personal.campusbookingsystem.exception.UnauthorizedAccessException;
import org.personal.campusbookingsystem.model.*;
import org.personal.campusbookingsystem.util.Session;
import org.personal.campusbookingsystem.util.SystemLogger;

import java.net.URL;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * Controls the Admin Dashboard: system statistics, pending booking
 * approvals, and full resource management (add/edit/delete). Only
 * reachable by users whose role is ADMIN (enforced by LoginController's
 * role-based routing).
 */
public class AdminDashboardController {

    @FXML private Label sidebarAdminNameLabel;
    @FXML private Label topBarAdminLabel;

    @FXML private Label totalResourcesLabel;
    @FXML private Label pendingBookingsLabel;
    @FXML private Label registeredUsersLabel;
    @FXML private Label availableResourcesLabel;

    @FXML private TableView<Booking> pendingBookingsTable;
    @FXML private TableColumn<Booking, String> colStudentName;
    @FXML private TableColumn<Booking, String> colBookingResourceAdmin;
    @FXML private TableColumn<Booking, String> colBookingDateAdmin;
    @FXML private TableColumn<Booking, String> colBookingTimeAdmin;
    @FXML private TableColumn<Booking, Void> colBookingActionsAdmin;

    @FXML private TableView<Resource> resourceTable;
    @FXML private TableColumn<Resource, String> colResId;
    @FXML private TableColumn<Resource, String> colResName;
    @FXML private TableColumn<Resource, String> colResType;
    @FXML private TableColumn<Resource, String> colResCapacity;
    @FXML private TableColumn<Resource, String> colResStatus;
    @FXML private TableColumn<Resource, Void> colResActions;

    private final AppContext app = AppContext.getInstance();
    private User currentUser;

    @FXML
    public void initialize() {
        currentUser = Session.getCurrentUser();
        if (currentUser == null || currentUser.getRole() != Role.ADMIN) {
            // UnauthorizedAccessException is thrown/logged if anyone but an Admin somehow reaches this screen.
            SystemLogger.logEvent(currentUser != null ? currentUser.getUserId() : "UNKNOWN",
                    "UNAUTHORIZED_ACCESS", "Non-admin attempted to open the Admin Dashboard");
            return;
        }

        sidebarAdminNameLabel.setText(currentUser.getName());
        topBarAdminLabel.setText("👤 " + currentUser.getName());

        setupPendingBookingsTable();
        setupResourceTable();
        refreshAll();
    }

    private void setupPendingBookingsTable() {
        colStudentName.setCellValueFactory(d -> new SimpleStringProperty(
                d.getValue().getUser() != null ? d.getValue().getUser().getName() : "-"));
        colBookingResourceAdmin.setCellValueFactory(d -> new SimpleStringProperty(
                d.getValue().getResource().getResourceName()));
        colBookingDateAdmin.setCellValueFactory(d -> new SimpleStringProperty(
                d.getValue().getBookingDate().toString()));
        colBookingTimeAdmin.setCellValueFactory(d -> new SimpleStringProperty(
                d.getValue().getTimeRangeText()));

        colBookingActionsAdmin.setCellFactory(col -> new TableCell<>() {
            private final Button approveBtn = new Button("Approve");
            private final Button rejectBtn = new Button("Reject");
            private final HBox box = new HBox(8, approveBtn, rejectBtn);
            {
                approveBtn.getStyleClass().add("approve-button");
                rejectBtn.getStyleClass().add("reject-button");
                approveBtn.setOnAction(e -> updateStatus(getTableView().getItems().get(getIndex()), BookingStatus.CONFIRMED));
                rejectBtn.setOnAction(e -> updateStatus(getTableView().getItems().get(getIndex()), BookingStatus.REJECTED));
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty ? null : box);
            }
        });
    }

    private void updateStatus(Booking booking, BookingStatus status) {
        try {
            app.getBookingService().updateBookingStatus(booking.getBookingId(), status, currentUser);
            refreshAll();
        } catch (UnauthorizedAccessException e) {
            new Alert(Alert.AlertType.ERROR, e.getMessage()).showAndWait();
        }
    }

    private void setupResourceTable() {
        colResId.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getResourceId()));
        colResName.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getResourceName()));
        colResType.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getResourceType()));
        colResCapacity.setCellValueFactory(d -> new SimpleStringProperty(String.valueOf(d.getValue().getCapacity())));
        colResStatus.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getStatus().toString()));

        colResActions.setCellFactory(col -> new TableCell<>() {
            private final Button editBtn = new Button("Edit");
            private final Button deleteBtn = new Button("Delete");
            private final HBox box = new HBox(8, editBtn, deleteBtn);
            {
                editBtn.setOnAction(e -> openEditResourceDialog(getTableView().getItems().get(getIndex())));
                deleteBtn.setOnAction(e -> deleteResource(getTableView().getItems().get(getIndex())));
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty ? null : box);
            }
        });
    }

    private void deleteResource(Resource resource) {
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION,
                "Delete " + resource.getResourceName() + "? This cannot be undone.");
        confirm.showAndWait().ifPresent(bt -> {
            if (bt == ButtonType.OK) {
                app.getResourceService().removeResource(resource.getResourceId());
                SystemLogger.logEvent(currentUser.getUserId(), "RESOURCE_DELETED", resource.getResourceId());
                refreshAll();
            }
        });
    }

    private void refreshAll() {
        List<Resource> allResources = app.getResourceService().getAll();
        List<Booking> allBookings = app.getBookingService().getAllBookings();

        totalResourcesLabel.setText(String.valueOf(allResources.size()));
        availableResourcesLabel.setText(String.valueOf(app.getResourceService().getAvailable().size()));
        registeredUsersLabel.setText(String.valueOf(app.getAuthService().getAllUsers().size()));

        List<Booking> pending = allBookings.stream()
                .filter(b -> b.getStatus() == BookingStatus.PENDING)
                .collect(Collectors.toList());
        pendingBookingsLabel.setText(String.valueOf(pending.size()));

        pendingBookingsTable.setItems(FXCollections.observableArrayList(pending));
        resourceTable.setItems(FXCollections.observableArrayList(allResources));
    }

    // ---------------------------------------------------------------
    // Add / Edit resource dialog (built programmatically to avoid a
    // dedicated FXML file for a simple form)
    // ---------------------------------------------------------------

    @FXML
    private void handleAddResource() {
        openResourceForm(null);
    }

    private void openEditResourceDialog(Resource resource) {
        openResourceForm(resource);
    }

    private void openResourceForm(Resource existing) {
        Stage dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.setTitle(existing == null ? "Add Resource" : "Edit Resource");

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(12);
        grid.setPadding(new Insets(25));

        TextField nameField = new TextField(existing != null ? existing.getResourceName() : "");
        TextField locationField = new TextField(existing != null ? existing.getLocation() : "");
        TextField capacityField = new TextField(existing != null ? String.valueOf(existing.getCapacity()) : "");
        ComboBox<String> typeCombo = new ComboBox<>(FXCollections.observableArrayList(
                "Study Room", "Lab Equipment", "Event Space"));
        typeCombo.getSelectionModel().select(existing == null ? "Study Room"
                : (existing instanceof StudyRoom ? "Study Room"
                : existing instanceof LabEquipment ? "Lab Equipment" : "Event Space"));
        ComboBox<ResourceStatus> statusCombo = new ComboBox<>(FXCollections.observableArrayList(ResourceStatus.values()));
        statusCombo.getSelectionModel().select(existing != null ? existing.getStatus() : ResourceStatus.AVAILABLE);

        grid.addRow(0, new Label("Name:"), nameField);
        grid.addRow(1, new Label("Location:"), locationField);
        grid.addRow(2, new Label("Capacity:"), capacityField);
        grid.addRow(3, new Label("Type:"), typeCombo);
        grid.addRow(4, new Label("Status:"), statusCombo);

        Label errorLabel = new Label();
        errorLabel.getStyleClass().add("error-text");
        grid.add(errorLabel, 0, 5, 2, 1);

        Button saveBtn = new Button(existing == null ? "Add Resource" : "Save Changes");
        saveBtn.getStyleClass().add("login-button");
        saveBtn.setOnAction(e -> {
            String name = nameField.getText();
            String location = locationField.getText();
            int capacity;
            try {
                capacity = Integer.parseInt(capacityField.getText().trim());
            } catch (NumberFormatException ex) {
                errorLabel.setText("Capacity must be a whole number.");
                return;
            }
            if (name == null || name.isBlank() || location == null || location.isBlank()) {
                errorLabel.setText("Name and location are required.");
                return;
            }
            ResourceStatus status = statusCombo.getValue();

            if (existing != null) {
                existing.setResourceName(name);
                existing.setLocation(location);
                existing.setCapacity(capacity);
                existing.setStatus(status);
                SystemLogger.logEvent(currentUser.getUserId(), "RESOURCE_UPDATED", existing.getResourceId());
            } else {
                String id = "R" + UUID.randomUUID().toString().substring(0, 6).toUpperCase();
                Resource newResource = switch (typeCombo.getValue()) {
                    case "Lab Equipment" -> new LabEquipment(id, name, location, capacity, status, "Lab Equipment");
                    case "Event Space" -> new EventSpace(id, name, location, capacity, status);
                    default -> new StudyRoom(id, name, location, capacity, status);
                };
                app.getResourceService().addResource(newResource);
                SystemLogger.logEvent(currentUser.getUserId(), "RESOURCE_CREATED", id);
            }

            refreshAll();
            dialog.close();
        });

        Button cancelBtn = new Button("Cancel");
        cancelBtn.setOnAction(e -> dialog.close());

        HBox buttons = new HBox(10, cancelBtn, saveBtn);
        grid.add(buttons, 0, 6, 2, 1);

        Scene scene = new Scene(grid);
        scene.getStylesheets().add(
                getClass().getResource("/org/personal/campusbookingsystem/css/style.css").toExternalForm());
        dialog.setScene(scene);
        dialog.showAndWait();
    }

    @FXML
    private void handleLogout() {
        SystemLogger.logEvent(currentUser.getUserId(), "LOGOUT", currentUser.getUsername() + " logged out");
        app.saveAll();
        Session.clear();
        try {
            URL url = getClass().getResource("/org/personal/campusbookingsystem/login/login.fxml");
            Parent root = FXMLLoader.load(url);
            Stage stage = (Stage) sidebarAdminNameLabel.getScene().getWindow();
            Scene scene = new Scene(root);
            scene.getStylesheets().add(
                    getClass().getResource("/org/personal/campusbookingsystem/css/style.css").toExternalForm());
            stage.setScene(scene);
            stage.setTitle("Campus Booking System");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
