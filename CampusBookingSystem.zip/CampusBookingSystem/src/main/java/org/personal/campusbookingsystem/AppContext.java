package org.personal.campusbookingsystem;

import org.personal.campusbookingsystem.manager.ResourceManager;
import org.personal.campusbookingsystem.model.*;
import org.personal.campusbookingsystem.service.AuthService;
import org.personal.campusbookingsystem.service.BookingService;
import org.personal.campusbookingsystem.service.ResourceService;
import org.personal.campusbookingsystem.service.impl.AuthServiceImpl;
import org.personal.campusbookingsystem.service.impl.BookingServiceImpl;
import org.personal.campusbookingsystem.service.impl.ResourceServiceImpl;
import org.personal.campusbookingsystem.util.FileIOHandler;
import org.personal.campusbookingsystem.util.PasswordUtil;
import org.personal.campusbookingsystem.util.SystemLogger;

import java.util.ArrayList;
import java.util.List;

/**
 * Application-wide composition root. Loads persisted data (or seeds
 * demo data on first run), wires up the service layer, and exposes a
 * single shared instance every controller can use. Also responsible
 * for saving all in-memory data back to disk (users.dat, resources.dat,
 * bookings.dat) whenever the application shuts down.
 */
public final class AppContext {

    private static final String USERS_FILE = "users.dat";
    private static final String RESOURCES_FILE = "resources.dat";
    private static final String BOOKINGS_FILE = "bookings.dat";

    private static AppContext instance;

    private final List<User> users;
    private final ResourceManager<Resource> resourceManager = new ResourceManager<>();
    private final List<Booking> bookings;

    private final AuthService authService;
    private final ResourceService resourceService;
    private final BookingService bookingService;

    private AppContext() {
        List<User> loadedUsers = FileIOHandler.readObjectFromFile(USERS_FILE);
        List<Resource> loadedResources = FileIOHandler.readObjectFromFile(RESOURCES_FILE);
        List<Booking> loadedBookings = FileIOHandler.readObjectFromFile(BOOKINGS_FILE);

        if (loadedUsers == null || loadedResources == null) {
            this.users = seedUsers();
            resourceManager.setAll(seedResources());
            this.bookings = new ArrayList<>();
            SystemLogger.logEvent("SYSTEM", "SEED_DATA", "First run detected - demo data seeded");
        } else {
            this.users = loadedUsers;
            resourceManager.setAll(loadedResources);
            this.bookings = loadedBookings != null ? loadedBookings : new ArrayList<>();
        }

        this.authService = new AuthServiceImpl(users);
        this.resourceService = new ResourceServiceImpl(resourceManager);
        this.bookingService = new BookingServiceImpl(bookings);
    }

    public static synchronized AppContext getInstance() {
        if (instance == null) {
            instance = new AppContext();
        }
        return instance;
    }

    public void saveAll() {
        FileIOHandler.writeObjectToFile(USERS_FILE, new ArrayList<>(users));
        FileIOHandler.writeObjectToFile(RESOURCES_FILE, resourceManager.getAll());
        FileIOHandler.writeObjectToFile(BOOKINGS_FILE, new ArrayList<>(bookings));
    }

    public AuthService getAuthService() {
        return authService;
    }

    public ResourceService getResourceService() {
        return resourceService;
    }

    public BookingService getBookingService() {
        return bookingService;
    }

    // ---------------------------------------------------------------
    // Demo data seeding (only runs the very first time the app starts)
    // ---------------------------------------------------------------

    private List<User> seedUsers() {
        List<User> list = new ArrayList<>();
        list.add(new Student("U001", "aisha", PasswordUtil.encode("student123"), "Aisha Shakya", "aisha@student.taylors.edu.my", "Year 3"));
        list.add(new Student("U002", "james", PasswordUtil.encode("student123"), "James Olen", "james@student.taylors.edu.my", "Year 2"));
        list.add(new Staff("U003", "rahul", PasswordUtil.encode("staff123"), "Rahul Patel", "rahul@taylors.edu.my", "Computer Science"));
        list.add(new Admin("U004", "safir", PasswordUtil.encode("admin123"), "Safir Gautam", "safir@taylors.edu.my"));
        return list;
    }

    private List<Resource> seedResources() {
        List<Resource> list = new ArrayList<>();
        list.add(new StudyRoom("R001", "Study Room A101", "Main Library, Floor 2", 8, ResourceStatus.AVAILABLE));
        list.add(new LabEquipment("R002", "Computer Lab", "Block C, Room 104", 30, ResourceStatus.AVAILABLE, "Computer Lab"));
        list.add(new StudyRoom("R003", "Single Study Room", "Library, Floor 3", 1, ResourceStatus.LIMITED));
        list.add(new EventSpace("R004", "Seminar Room 101", "Humanities Block", 25, ResourceStatus.MAINTENANCE));
        list.add(new EventSpace("R005", "Innovation Hub", "Student Union, Level 1", 40, ResourceStatus.AVAILABLE));
        list.add(new LabEquipment("R006", "Research Lab", "Block B, Room 207", 16, ResourceStatus.OCCUPIED, "Laboratory"));
        list.add(new LabEquipment("R007", "Portable Projector #1", "Equipment Store", 1, ResourceStatus.AVAILABLE, "Projector"));
        return list;
    }
}
