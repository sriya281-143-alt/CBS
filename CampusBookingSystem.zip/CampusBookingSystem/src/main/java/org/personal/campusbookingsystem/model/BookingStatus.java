package org.personal.campusbookingsystem.model;

/**
 * Lifecycle status of a booking request.
 */
public enum BookingStatus {
    PENDING,
    CONFIRMED,
    REJECTED,
    CANCELLED
}
