package org.personal.campusbookingsystem.service;

import org.personal.campusbookingsystem.model.User;

import java.util.List;

public interface AuthService {

    List<User> getAllUsers();

    /** Returns the matching User if the credentials are valid, otherwise null. */
    User login(String username, String password);

    /** Registers a brand new user (used by Admin > Manage Users). */
    void register(User user);

    boolean usernameExists(String username);
}
