package org.personal.campusbookingsystem.manager;

import org.personal.campusbookingsystem.model.Resource;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Generic manager class for any type of bookable resource. Using
 * generics (T extends Resource) means the exact same class can manage
 * StudyRooms, LabEquipment or EventSpaces (or any future Resource
 * subtype) without duplicating code, demonstrating the assignment's
 * "reusable ResourceManager&lt;T&gt;" requirement.
 */
public class ResourceManager<T extends Resource> {

    private final List<T> resources = new ArrayList<>();

    public void addResource(T resource) {
        resources.add(resource);
    }

    public boolean removeResource(String resourceId) {
        return resources.removeIf(r -> r.getResourceId().equalsIgnoreCase(resourceId));
    }

    public T findById(String resourceId) {
        return resources.stream()
                .filter(r -> r.getResourceId().equalsIgnoreCase(resourceId))
                .findFirst()
                .orElse(null);
    }

    public List<T> searchByType(String type) {
        if (type == null || type.isBlank()) {
            return getAll();
        }
        return resources.stream()
                .filter(r -> r.getResourceType().equalsIgnoreCase(type))
                .collect(Collectors.toList());
    }

    public List<T> searchByLocation(String location) {
        if (location == null || location.isBlank()) {
            return getAll();
        }
        return resources.stream()
                .filter(r -> r.getLocation() != null && r.getLocation().toLowerCase().contains(location.toLowerCase()))
                .collect(Collectors.toList());
    }

    public List<T> getAvailableResources() {
        return resources.stream()
                .filter(Resource::checkAvailability)
                .collect(Collectors.toList());
    }

    public List<T> getAll() {
        return new ArrayList<>(resources);
    }

    public void setAll(List<T> newResources) {
        resources.clear();
        if (newResources != null) {
            resources.addAll(newResources);
        }
    }

    public int count() {
        return resources.size();
    }
}
