package org.personal.campusbookingsystem.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import org.personal.campusbookingsystem.AppContext;
import org.personal.campusbookingsystem.model.Role;
import org.personal.campusbookingsystem.model.User;
import org.personal.campusbookingsystem.util.Session;

import java.net.URL;

/**
 * Controls the Login Form: authenticates the user against
 * {@link org.personal.campusbookingsystem.service.AuthService} and then
 * performs role-based routing to either the Resource Listing Form
 * (Student/Staff) or the Admin Dashboard (Admin), per the screen flow
 * diagram in the Part A report.
 */
public class LoginController {

    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private Label errorLabel;

    @FXML
    private void handleLogin(ActionEvent event) {

        String username = usernameField.getText() == null ? "" : usernameField.getText().trim();
        String password = passwordField.getText() == null ? "" : passwordField.getText();

        if (username.isEmpty() || password.isEmpty()) {
            showError("Please enter both username and password.");
            return;
        }

        User user = AppContext.getInstance().getAuthService().login(username, password);

        if (user == null) {
            showError("Invalid username or password. Please try again.");
            return;
        }

        Session.setCurrentUser(user);

        try {
            String fxml = user.getRole() == Role.ADMIN
                    ? "/org/personal/campusbookingsystem/dashboard/admin-dashboard.fxml"
                    : "/org/personal/campusbookingsystem/resources/resources.fxml";

            URL url = getClass().getResource(fxml);
            FXMLLoader loader = new FXMLLoader(url);
            Parent root = loader.load();

            Scene scene = new Scene(root);
            scene.getStylesheets().add(
                    getClass().getResource("/org/personal/campusbookingsystem/css/style.css").toExternalForm()
            );

            Stage stage = (Stage) usernameField.getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle(user.getRole() == Role.ADMIN ? "Admin Dashboard" : "Campus Resources");
            stage.show();

        } catch (Exception e) {
            e.printStackTrace();
            showError("Unable to open the dashboard. Please try again.");
        }
    }

    private void showError(String message) {
        errorLabel.setText(message);
        errorLabel.setVisible(true);
        errorLabel.setManaged(true);
    }
}
