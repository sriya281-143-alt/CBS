package org.personal.campusbookingsystem.service.impl;

import org.personal.campusbookingsystem.exception.InvalidBookingDurationException;
import org.personal.campusbookingsystem.exception.ResourceUnavailableException;
import org.personal.campusbookingsystem.exception.UnauthorizedAccessException;
import org.personal.campusbookingsystem.model.*;
import org.personal.campusbookingsystem.service.BookingService;
import org.personal.campusbookingsystem.util.SystemLogger;

import java.time.Duration;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

/**
 * Acts as the system's BookingManager (see class diagram): the central
 * controller responsible for creating/cancelling bookings, validating
 * booking rules (no double-booking, duration limits) and logging every
 * booking event through {@link SystemLogger}.
 */
public class BookingServiceImpl implements BookingService {

    private static final int MAX_DURATION_HOURS = 3;
    private final AtomicInteger idCounter = new AtomicInteger(1);
    private final List<Booking> bookings;

    public BookingServiceImpl(List<Booking> bookings) {
        this.bookings = bookings;
        // keep the counter ahead of any bookings already loaded from disk
        for (Booking b : bookings) {
            try {
                int n = Integer.parseInt(b.getBookingId().replaceAll("\\D", ""));
                if (n >= idCounter.get()) {
                    idCounter.set(n + 1);
                }
            } catch (NumberFormatException ignored) {
            }
        }
    }

    @Override
    public Booking createBooking(Booking booking) throws ResourceUnavailableException, InvalidBookingDurationException {

        // 1) Duration validation
        if (booking.getEndTime().isBefore(booking.getStartTime()) || booking.getEndTime().equals(booking.getStartTime())) {
            throw new InvalidBookingDurationException("End time must be after start time.");
        }
        Duration duration = Duration.between(booking.getStartTime(), booking.getEndTime());
        if (duration.toMinutes() > MAX_DURATION_HOURS * 60) {
            throw new InvalidBookingDurationException("Booking duration cannot exceed " + MAX_DURATION_HOURS + " hours.");
        }

        // 2) Resource availability
        Resource resource = booking.getResource();
        if (resource == null || !resource.checkAvailability()) {
            throw new ResourceUnavailableException("Resource '" + (resource != null ? resource.getResourceName() : "?") + "' is not available.");
        }

        // 3) Double-booking / time-slot conflict check
        boolean conflict = bookings.stream()
                .filter(b -> b.getStatus() != BookingStatus.CANCELLED && b.getStatus() != BookingStatus.REJECTED)
                .filter(b -> b.getResource().getResourceId().equals(resource.getResourceId()))
                .filter(b -> b.getBookingDate().equals(booking.getBookingDate()))
                .anyMatch(b -> booking.getStartTime().isBefore(b.getEndTime()) && b.getStartTime().isBefore(booking.getEndTime()));
        if (conflict) {
            throw new ResourceUnavailableException("This resource is already booked for the selected time slot.");
        }

        // 4) Assign ID + initial status (students require approval)
        booking.setBookingId("BK" + String.format("%04d", idCounter.getAndIncrement()));
        boolean requiresApproval = booking.getUser() != null && booking.getUser().getRole() == Role.STUDENT;
        booking.setStatus(requiresApproval ? BookingStatus.PENDING : BookingStatus.CONFIRMED);

        bookings.add(booking);

        if (!requiresApproval) {
            resource.updateStatus(ResourceStatus.OCCUPIED);
        }

        SystemLogger.logEvent(booking.getUser() != null ? booking.getUser().getUserId() : "?",
                "BOOKING_CREATED", booking.getBookingId() + " for " + resource.getResourceName() + " -> " + booking.getStatus());

        return booking;
    }

    @Override
    public List<Booking> getAllBookings() {
        return bookings;
    }

    @Override
    public List<Booking> getBookingsForUser(String userId) {
        return bookings.stream()
                .filter(b -> b.getUser() != null && b.getUser().getUserId().equals(userId))
                .collect(Collectors.toList());
    }

    @Override
    public Booking findBookingById(String bookingId) {
        for (Booking booking : bookings) {
            if (booking.getBookingId().equalsIgnoreCase(bookingId)) {
                return booking;
            }
        }
        return null;
    }

    @Override
    public boolean removeBooking(String bookingId) {
        Booking booking = findBookingById(bookingId);
        if (booking != null) {
            bookings.remove(booking);
            return true;
        }
        return false;
    }

    @Override
    public void updateBookingStatus(String bookingId, BookingStatus newStatus, User actingUser) throws UnauthorizedAccessException {
        if (actingUser == null || actingUser.getRole() == Role.STUDENT) {
            throw new UnauthorizedAccessException("Only Staff or Admin can approve/reject bookings.");
        }
        Booking booking = findBookingById(bookingId);
        if (booking == null) {
            return;
        }
        booking.setStatus(newStatus);
        if (newStatus == BookingStatus.CONFIRMED) {
            booking.getResource().updateStatus(ResourceStatus.OCCUPIED);
        } else if (newStatus == BookingStatus.REJECTED) {
            booking.getResource().updateStatus(ResourceStatus.AVAILABLE);
        }
        SystemLogger.logEvent(actingUser.getUserId(), "BOOKING_" + newStatus, bookingId + " updated by " + actingUser.getUsername());
    }

    @Override
    public void cancelBooking(String bookingId, User actingUser) throws UnauthorizedAccessException {
        Booking booking = findBookingById(bookingId);
        if (booking == null) {
            return;
        }
        boolean isOwner = booking.getUser() != null && actingUser != null
                && booking.getUser().getUserId().equals(actingUser.getUserId());
        boolean isAdmin = actingUser != null && actingUser.getRole() == Role.ADMIN;

        if (!isOwner && !isAdmin) {
            throw new UnauthorizedAccessException("You do not have permission to cancel this booking.");
        }

        booking.setStatus(BookingStatus.CANCELLED);
        booking.getResource().updateStatus(ResourceStatus.AVAILABLE);
        SystemLogger.logEvent(actingUser.getUserId(), "BOOKING_CANCELLED", bookingId + " cancelled by " + actingUser.getUsername());
    }
}
