package org.personal.campusbookingsystem.model;

/**
 * A Student can browse resources and request bookings, but cannot
 * approve/override bookings or manage resources (enforced by the
 * service layer's role checks).
 */
public class Student extends User {

    private static final long serialVersionUID = 1L;

    private String yearOfStudy;

    public Student() {
        super();
    }

    public Student(String userId, String username, String password, String name, String email, String yearOfStudy) {
        super(userId, username, password, name, email);
        this.yearOfStudy = yearOfStudy;
    }

    public String getYearOfStudy() {
        return yearOfStudy;
    }

    public void setYearOfStudy(String yearOfStudy) {
        this.yearOfStudy = yearOfStudy;
    }

    /** Students may only view resources; kept here to mirror the class diagram. */
    public String viewResources() {
        return "Viewing available campus resources";
    }

    /** Students may only request a booking (subject to admin/staff approval). */
    public String requestBooking() {
        return "Booking request submitted for approval";
    }

    @Override
    public Role getRole() {
        return Role.STUDENT;
    }
}
