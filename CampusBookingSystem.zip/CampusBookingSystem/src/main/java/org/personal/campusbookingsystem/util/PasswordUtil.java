package org.personal.campusbookingsystem.util;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

/**
 * Encodes credentials before they are written to disk so that no plain
 * text password is ever persisted, satisfying the assignment's
 * "encoded text or binary file" requirement. A salted SHA-256 hash
 * (Base64 encoded) is used rather than reversible encoding.
 */
public final class PasswordUtil {

    private static final String SALT = "CRSSBS-ITS66704";

    private PasswordUtil() {
    }

    public static String encode(String plainText) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest((SALT + plainText).getBytes(StandardCharsets.UTF_8));
            return Base64.getEncoder().encodeToString(hash);
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("SHA-256 not available", e);
        }
    }

    public static boolean matches(String plainText, String encoded) {
        if (plainText == null || encoded == null) {
            return false;
        }
        return encode(plainText).equals(encoded);
    }
}
