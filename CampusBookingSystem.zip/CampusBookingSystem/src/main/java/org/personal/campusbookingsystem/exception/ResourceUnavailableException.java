package org.personal.campusbookingsystem.exception;

/**
 * Thrown when a user attempts to book a resource that is already
 * booked, unavailable, or has no free time slot at the requested date
 * and time.
 */
public class ResourceUnavailableException extends BookingException {

    public ResourceUnavailableException(String message) {
        super(message);
    }
}
