package org.personal.campusbookingsystem.service;

import org.personal.campusbookingsystem.model.Resource;

import java.util.List;

public interface ResourceService {

    void addResource(Resource resource);

    boolean removeResource(String resourceId);

    Resource findById(String resourceId);

    List<Resource> getAll();

    List<Resource> getAvailable();

    List<Resource> search(String keyword, String type, String location);
}
