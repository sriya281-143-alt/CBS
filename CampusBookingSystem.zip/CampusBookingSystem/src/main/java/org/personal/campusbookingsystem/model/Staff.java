package org.personal.campusbookingsystem.model;

/**
 * Staff members can book resources directly and manage bookings that
 * belong to them (modify / cancel), plus approve or reject student
 * booking requests.
 */
public class Staff extends User {

    private static final long serialVersionUID = 1L;

    private String department;

    public Staff() {
        super();
    }

    public Staff(String userId, String username, String password, String name, String email, String department) {
        super(userId, username, password, name, email);
        this.department = department;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String modifyOwnBooking() {
        return "Modifying own booking";
    }

    public String cancelOwnBooking() {
        return "Cancelling own booking";
    }

    @Override
    public Role getRole() {
        return Role.STAFF;
    }
}
