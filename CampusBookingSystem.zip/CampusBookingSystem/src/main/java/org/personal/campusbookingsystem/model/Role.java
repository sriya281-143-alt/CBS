package org.personal.campusbookingsystem.model;

/**
 * Enumeration of all user roles supported by the system.
 * Used throughout the system for role-based access control (RBAC).
 */
public enum Role {
    STUDENT,
    STAFF,
    ADMIN
}
