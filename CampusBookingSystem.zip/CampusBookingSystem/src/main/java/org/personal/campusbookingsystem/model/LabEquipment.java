package org.personal.campusbookingsystem.model;

/** Computer labs and portable equipment (e.g. projectors). */
public class LabEquipment extends Resource {

    private static final long serialVersionUID = 1L;

    private String equipmentCategory;

    public LabEquipment() {
        super();
    }

    public LabEquipment(String resourceId, String resourceName, String location,
                         int capacity, ResourceStatus status, String equipmentCategory) {
        super(resourceId, resourceName, location, capacity, status);
        this.equipmentCategory = equipmentCategory;
    }

    public String getEquipmentCategory() {
        return equipmentCategory;
    }

    public void setEquipmentCategory(String equipmentCategory) {
        this.equipmentCategory = equipmentCategory;
    }

    @Override
    public String getResourceType() {
        return equipmentCategory != null ? equipmentCategory : "Lab Equipment";
    }
}
