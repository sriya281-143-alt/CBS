package org.personal.campusbookingsystem.model;

/**
 * Administrator with full control over the system: managing users,
 * resources, approving/rejecting/overriding bookings and viewing
 * system logs.
 */
public class Admin extends User {

    private static final long serialVersionUID = 1L;

    public Admin() {
        super();
    }

    public Admin(String userId, String username, String password, String name, String email) {
        super(userId, username, password, name, email);
    }

    public String approveBooking() {
        return "Approving booking request";
    }

    public String overrideBooking() {
        return "Overriding booking";
    }

    public String manageResources() {
        return "Managing campus resources";
    }

    public String viewSystemLogs() {
        return "Viewing system logs";
    }

    @Override
    public Role getRole() {
        return Role.ADMIN;
    }
}
