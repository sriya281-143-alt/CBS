package org.personal.campusbookingsystem.model;

/** A quiet room reserved for individual or group study. */
public class StudyRoom extends Resource {

    private static final long serialVersionUID = 1L;

    public StudyRoom() {
        super();
    }

    public StudyRoom(String resourceId, String resourceName, String location,
                      int capacity, ResourceStatus status) {
        super(resourceId, resourceName, location, capacity, status);
    }

    @Override
    public String getResourceType() {
        return "Study Room";
    }
}
