package org.personal.campusbookingsystem.controller;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import org.personal.campusbookingsystem.AppContext;
import org.personal.campusbookingsystem.exception.UnauthorizedAccessException;
import org.personal.campusbookingsystem.model.*;
import org.personal.campusbookingsystem.util.Session;
import org.personal.campusbookingsystem.util.SystemLogger;

import java.net.URL;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Controls the Resource Listing Form. Displays every campus resource as
 * a searchable/filterable card grid and lets the current user open the
 * Booking Form for any available resource. Also drives the "My
 * Bookings" table where the user can review and cancel their own
 * bookings.
 */
public class ResourcesController {

    @FXML private VBox resourcesView;
    @FXML private VBox myBookingsView;

    @FXML private Label sidebarUserNameLabel;
    @FXML private Label sidebarUserRoleLabel;
    @FXML private Label topBarUserLabel;

    @FXML private Label availableCountLabel;
    @FXML private Label activeBookingsLabel;
    @FXML private Label pendingRequestsLabel;

    @FXML private TextField searchField;
    @FXML private ComboBox<String> typeFilterCombo;
    @FXML private ComboBox<String> locationFilterCombo;
    @FXML private ComboBox<String> statusFilterCombo;

    @FXML private javafx.scene.layout.TilePane resourceCardsPane;

    @FXML private TableView<Booking> myBookingsTable;
    @FXML private TableColumn<Booking, String> colBookingResource;
    @FXML private TableColumn<Booking, String> colBookingDate;
    @FXML private TableColumn<Booking, String> colBookingTime;
    @FXML private TableColumn<Booking, String> colBookingPurpose;
    @FXML private TableColumn<Booking, String> colBookingStatus;
    @FXML private TableColumn<Booking, Void> colBookingAction;

    private final AppContext app = AppContext.getInstance();
    private User currentUser;

    @FXML
    public void initialize() {
        currentUser = Session.getCurrentUser();
        if (currentUser == null) {
            return;
        }

        sidebarUserNameLabel.setText(currentUser.getName());
        sidebarUserRoleLabel.setText(currentUser.getRole().toString());
        topBarUserLabel.setText("👤 " + currentUser.getName());

        setupFilterCombos();
        setupMyBookingsTable();
        renderResourceCards(app.getResourceService().getAll());
        refreshStats();
    }

    private void setupFilterCombos() {
        ObservableList<String> types = FXCollections.observableArrayList("All Types");
        ObservableList<String> locations = FXCollections.observableArrayList("All Locations");
        ObservableList<String> statuses = FXCollections.observableArrayList("All Status",
                "AVAILABLE", "LIMITED", "OCCUPIED", "MAINTENANCE");

        for (Resource r : app.getResourceService().getAll()) {
            if (!types.contains(r.getResourceType())) types.add(r.getResourceType());
            if (!locations.contains(r.getLocation())) locations.add(r.getLocation());
        }

        typeFilterCombo.setItems(types);
        locationFilterCombo.setItems(locations);
        statusFilterCombo.setItems(statuses);
        typeFilterCombo.getSelectionModel().selectFirst();
        locationFilterCombo.getSelectionModel().selectFirst();
        statusFilterCombo.getSelectionModel().selectFirst();
    }

    private void setupMyBookingsTable() {
        colBookingResource.setCellValueFactory(data ->
                new SimpleStringProperty(data.getValue().getResource().getResourceName()));
        colBookingDate.setCellValueFactory(data ->
                new SimpleStringProperty(data.getValue().getBookingDate().toString()));
        colBookingTime.setCellValueFactory(data ->
                new SimpleStringProperty(data.getValue().getTimeRangeText()));
        colBookingPurpose.setCellValueFactory(data ->
                new SimpleStringProperty(data.getValue().getPurpose()));
        colBookingStatus.setCellValueFactory(data ->
                new SimpleStringProperty(data.getValue().getStatus().toString()));

        colBookingAction.setCellFactory(col -> new TableCell<>() {
            private final Button cancelBtn = new Button("Cancel");
            {
                cancelBtn.setOnAction(e -> {
                    Booking booking = getTableView().getItems().get(getIndex());
                    handleCancelBooking(booking);
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                    return;
                }
                Booking booking = getTableView().getItems().get(getIndex());
                boolean cancellable = booking.getStatus() == BookingStatus.PENDING
                        || booking.getStatus() == BookingStatus.CONFIRMED;
                cancelBtn.setDisable(!cancellable);
                setGraphic(cancelBtn);
            }
        });

        refreshMyBookingsTable();
    }

    private void refreshMyBookingsTable() {
        List<Booking> mine = app.getBookingService().getBookingsForUser(currentUser.getUserId());
        myBookingsTable.setItems(FXCollections.observableArrayList(mine));
    }

    private void handleCancelBooking(Booking booking) {
        try {
            app.getBookingService().cancelBooking(booking.getBookingId(), currentUser);
            refreshMyBookingsTable();
            renderResourceCards(app.getResourceService().getAll());
            refreshStats();
        } catch (UnauthorizedAccessException e) {
            new Alert(Alert.AlertType.ERROR, e.getMessage()).showAndWait();
        }
    }

    private void refreshStats() {
        availableCountLabel.setText(String.valueOf(app.getResourceService().getAvailable().size()));

        List<Booking> mine = app.getBookingService().getBookingsForUser(currentUser.getUserId());
        long active = mine.stream().filter(b -> b.getStatus() == BookingStatus.CONFIRMED).count();
        long pending = mine.stream().filter(b -> b.getStatus() == BookingStatus.PENDING).count();

        activeBookingsLabel.setText(String.valueOf(active));
        pendingRequestsLabel.setText(String.valueOf(pending));
    }

    private void renderResourceCards(List<Resource> resources) {
        resourceCardsPane.getChildren().clear();
        for (Resource r : resources) {
            resourceCardsPane.getChildren().add(buildResourceCard(r));
        }
    }

    private VBox buildResourceCard(Resource r) {
        VBox card = new VBox();
        card.getStyleClass().add("resource-card");
        card.setSpacing(10);

        Label badge = new Label(r.getStatus().toString());
        badge.getStyleClass().add(switch (r.getStatus()) {
            case AVAILABLE -> "available-badge";
            case LIMITED -> "limited-badge";
            case OCCUPIED -> "occupied-badge";
            case MAINTENANCE -> "maintenance-badge";
        });

        Label title = new Label(r.getResourceName());
        title.getStyleClass().add("resource-title");

        Label type = new Label("Type: " + r.getResourceType());
        Label location = new Label("📍 " + r.getLocation());
        Label capacity = new Label("👥 Up to " + r.getCapacity() + " people");

        Button bookBtn = new Button("Book Now");
        bookBtn.getStyleClass().add("book-button");
        bookBtn.setDisable(!r.checkAvailability());
        bookBtn.setOnAction(e -> openBookingDialog(r));

        card.getChildren().addAll(badge, title, type, location, capacity, bookBtn);
        return card;
    }

    private void openBookingDialog(Resource resource) {
        try {
            URL url = getClass().getResource("/org/personal/campusbookingsystem/booking/booking.fxml");
            FXMLLoader loader = new FXMLLoader(url);
            Parent root = loader.load();

            BookingController controller = loader.getController();
            controller.setResource(resource);
            controller.setOnBookingCompleted(() -> {
                renderResourceCards(app.getResourceService().getAll());
                refreshStats();
                refreshMyBookingsTable();
            });

            Stage dialog = new Stage();
            dialog.initModality(Modality.APPLICATION_MODAL);
            dialog.setTitle("New Booking");
            Scene scene = new Scene(root);
            scene.getStylesheets().add(
                    getClass().getResource("/org/personal/campusbookingsystem/css/style.css").toExternalForm());
            dialog.setScene(scene);
            dialog.showAndWait();

        } catch (Exception e) {
            e.printStackTrace();
            new Alert(Alert.AlertType.ERROR, "Unable to open the booking form.").showAndWait();
        }
    }

    @FXML
    private void handleSearch() {
        String keyword = searchField.getText();
        String type = typeFilterCombo.getValue();
        String location = locationFilterCombo.getValue();
        String status = statusFilterCombo.getValue();

        List<Resource> results = app.getResourceService().search(keyword, type, location);
        if (status != null && !status.isBlank() && !"All Status".equals(status)) {
            results = results.stream()
                    .filter(r -> r.getStatus().toString().equalsIgnoreCase(status))
                    .collect(Collectors.toList());
        }
        renderResourceCards(results);
    }

    @FXML
    private void handleResetFilters() {
        searchField.clear();
        typeFilterCombo.getSelectionModel().selectFirst();
        locationFilterCombo.getSelectionModel().selectFirst();
        statusFilterCombo.getSelectionModel().selectFirst();
        renderResourceCards(app.getResourceService().getAll());
    }

    @FXML
    private void showResourcesView() {
        resourcesView.setVisible(true);
        resourcesView.setManaged(true);
        myBookingsView.setVisible(false);
        myBookingsView.setManaged(false);
    }

    @FXML
    private void showMyBookingsView() {
        refreshMyBookingsTable();
        resourcesView.setVisible(false);
        resourcesView.setManaged(false);
        myBookingsView.setVisible(true);
        myBookingsView.setManaged(true);
    }

    @FXML
    private void showProfile() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Profile");
        alert.setHeaderText(currentUser.getName());
        alert.setContentText("User ID: " + currentUser.getUserId()
                + "\nUsername: " + currentUser.getUsername()
                + "\nEmail: " + currentUser.getEmail()
                + "\nRole: " + currentUser.getRole());
        alert.showAndWait();
    }

    @FXML
    private void handleLogout() {
        SystemLogger.logEvent(currentUser.getUserId(), "LOGOUT", currentUser.getUsername() + " logged out");
        app.saveAll();
        Session.clear();
        try {
            URL url = getClass().getResource("/org/personal/campusbookingsystem/login/login.fxml");
            Parent root = FXMLLoader.load(url);
            Stage stage = (Stage) sidebarUserNameLabel.getScene().getWindow();
            Scene scene = new Scene(root);
            scene.getStylesheets().add(
                    getClass().getResource("/org/personal/campusbookingsystem/css/style.css").toExternalForm());
            stage.setScene(scene);
            stage.setTitle("Campus Booking System");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
