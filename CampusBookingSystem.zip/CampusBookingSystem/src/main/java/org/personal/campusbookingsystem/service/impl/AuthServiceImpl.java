package org.personal.campusbookingsystem.service.impl;

import org.personal.campusbookingsystem.model.User;
import org.personal.campusbookingsystem.service.AuthService;
import org.personal.campusbookingsystem.util.SystemLogger;

import java.util.List;

public class AuthServiceImpl implements AuthService {

    private final List<User> users;

    public AuthServiceImpl(List<User> users) {
        this.users = users;
    }

    @Override
    public User login(String username, String password) {
        for (User user : users) {
            if (user.getUsername().equalsIgnoreCase(username)) {
                if (user.login(password)) {
                    SystemLogger.logEvent(user.getUserId(), "LOGIN_SUCCESS", user.getUsername() + " logged in");
                    return user;
                }
                SystemLogger.logEvent(user.getUserId(), "LOGIN_FAILURE", "Incorrect password for " + username);
                return null;
            }
        }
        SystemLogger.logEvent("UNKNOWN", "LOGIN_FAILURE", "Unknown username " + username);
        return null;
    }

    @Override
    public List<User> getAllUsers() {
        return users;
    }

    @Override
    public void register(User user) {
        users.add(user);
    }

    @Override
    public boolean usernameExists(String username) {
        return users.stream().anyMatch(u -> u.getUsername().equalsIgnoreCase(username));
    }
}
