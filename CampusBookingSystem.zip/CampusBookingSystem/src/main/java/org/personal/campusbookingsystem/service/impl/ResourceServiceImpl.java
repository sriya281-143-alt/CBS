package org.personal.campusbookingsystem.service.impl;

import org.personal.campusbookingsystem.manager.ResourceManager;
import org.personal.campusbookingsystem.model.Resource;
import org.personal.campusbookingsystem.service.ResourceService;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Thin service wrapper around the generic {@link ResourceManager}. Kept
 * separate from ResourceManager so controllers depend on an interface
 * (ResourceService) rather than the generic collection class directly.
 */
public class ResourceServiceImpl implements ResourceService {

    private final ResourceManager<Resource> resourceManager;

    public ResourceServiceImpl(ResourceManager<Resource> resourceManager) {
        this.resourceManager = resourceManager;
    }

    @Override
    public void addResource(Resource resource) {
        resourceManager.addResource(resource);
    }

    @Override
    public boolean removeResource(String resourceId) {
        return resourceManager.removeResource(resourceId);
    }

    @Override
    public Resource findById(String resourceId) {
        return resourceManager.findById(resourceId);
    }

    @Override
    public List<Resource> getAll() {
        return resourceManager.getAll();
    }

    @Override
    public List<Resource> getAvailable() {
        return resourceManager.getAvailableResources();
    }

    @Override
    public List<Resource> search(String keyword, String type, String location) {
        return resourceManager.getAll().stream()
                .filter(r -> keyword == null || keyword.isBlank()
                        || r.getResourceName().toLowerCase().contains(keyword.toLowerCase())
                        || r.getLocation().toLowerCase().contains(keyword.toLowerCase()))
                .filter(r -> type == null || type.isBlank() || "All Types".equalsIgnoreCase(type)
                        || r.getResourceType().equalsIgnoreCase(type))
                .filter(r -> location == null || location.isBlank() || "All Locations".equalsIgnoreCase(location)
                        || r.getLocation().equalsIgnoreCase(location))
                .collect(Collectors.toList());
    }
}
