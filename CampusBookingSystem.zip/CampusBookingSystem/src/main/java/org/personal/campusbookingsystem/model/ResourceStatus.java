package org.personal.campusbookingsystem.model;

/**
 * Availability status of a bookable resource.
 */
public enum ResourceStatus {
    AVAILABLE,
    LIMITED,
    OCCUPIED,
    MAINTENANCE
}
