package org.personal.campusbookingsystem.exception;

/**
 * Thrown when a booking's requested duration does not comply with the
 * system's validation rules (e.g. end time before start time, or a
 * duration that exceeds the maximum allowed booking length).
 */
public class InvalidBookingDurationException extends BookingException {

    public InvalidBookingDurationException(String message) {
        super(message);
    }
}
