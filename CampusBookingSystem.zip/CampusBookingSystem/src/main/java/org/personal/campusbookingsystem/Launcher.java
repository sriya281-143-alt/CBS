package org.personal.campusbookingsystem;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Launcher extends Application {

    @Override
    public void start(Stage stage) throws Exception {

        // Touch AppContext once at startup so data is loaded/seeded before the UI appears.
        AppContext.getInstance();

        FXMLLoader loader = new FXMLLoader(
                getClass().getResource("/org/personal/campusbookingsystem/login/login.fxml")
        );

        Scene scene = new Scene(loader.load());
        scene.getStylesheets().add(
                getClass().getResource("/org/personal/campusbookingsystem/css/style.css").toExternalForm()
        );
        stage.setTitle("Campus Booking System");
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();

        // Persist all in-memory data (users/resources/bookings) whenever the app closes.
        stage.setOnCloseRequest(event -> AppContext.getInstance().saveAll());
    }

    public static void main(String[] args) {
        launch(args);
    }
}
