package org.personal.campusbookingsystem.exception;

import java.time.LocalDateTime;

/**
 * Abstract superclass for every booking-related checked exception in the
 * system. Provides a common timestamp/message contract so callers can
 * catch BookingException generically, or catch specific subclasses when
 * they need to react differently.
 */
public abstract class BookingException extends Exception {

    private final LocalDateTime timestamp;

    protected BookingException(String message) {
        super(message);
        this.timestamp = LocalDateTime.now();
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }
}
