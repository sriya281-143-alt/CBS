package org.personal.campusbookingsystem.model;

/** Larger collaborative / event spaces such as halls and discussion rooms. */
public class EventSpace extends Resource {

    private static final long serialVersionUID = 1L;

    public EventSpace() {
        super();
    }

    public EventSpace(String resourceId, String resourceName, String location,
                       int capacity, ResourceStatus status) {
        super(resourceId, resourceName, location, capacity, status);
    }

    @Override
    public String getResourceType() {
        return "Event Space";
    }
}
