package org.personal.campusbookingsystem.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

/**
 * Represents a single booking/reservation of a {@link Resource} by a
 * {@link User}. Only IDs are strictly required for persistence, but the
 * full user/resource object graph is kept in memory for convenience
 * while the app is running (both User and Resource are Serializable so
 * this also serializes cleanly to bookings.dat).
 */
public class Booking implements Serializable {

    private static final long serialVersionUID = 1L;
    private static final DateTimeFormatter TIME_FMT = DateTimeFormatter.ofPattern("HH:mm");

    private String bookingId;
    private User user;
    private Resource resource;
    private LocalDate bookingDate;
    private LocalTime startTime;
    private LocalTime endTime;
    private String purpose;
    private String creatorName;
    private BookingStatus status;

    public Booking() {
    }

    public Booking(String bookingId, User user, Resource resource,
                    LocalDate bookingDate, LocalTime startTime,
                    LocalTime endTime, String purpose, BookingStatus status) {
        this.bookingId = bookingId;
        this.user = user;
        this.resource = resource;
        this.bookingDate = bookingDate;
        this.startTime = startTime;
        this.endTime = endTime;
        this.purpose = purpose;
        this.status = status;
        this.creatorName = user != null ? user.getName() : null;
    }

    public String getBookingId() {
        return bookingId;
    }

    public void setBookingId(String bookingId) {
        this.bookingId = bookingId;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
        this.creatorName = user != null ? user.getName() : this.creatorName;
    }

    public Resource getResource() {
        return resource;
    }

    public void setResource(Resource resource) {
        this.resource = resource;
    }

    public LocalDate getBookingDate() {
        return bookingDate;
    }

    public void setBookingDate(LocalDate bookingDate) {
        this.bookingDate = bookingDate;
    }

    public LocalTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalTime startTime) {
        this.startTime = startTime;
    }

    public LocalTime getEndTime() {
        return endTime;
    }

    public void setEndTime(LocalTime endTime) {
        this.endTime = endTime;
    }

    public String getPurpose() {
        return purpose;
    }

    public void setPurpose(String purpose) {
        this.purpose = purpose;
    }

    public String getCreatorName() {
        return creatorName;
    }

    public void setCreatorName(String creatorName) {
        this.creatorName = creatorName;
    }

    public BookingStatus getStatus() {
        return status;
    }

    public void setStatus(BookingStatus status) {
        this.status = status;
    }

    /** Convenience method used by TableView cell factories in the admin dashboard. */
    public String getTimeRangeText() {
        return startTime.format(TIME_FMT) + " - " + endTime.format(TIME_FMT);
    }

    @Override
    public String toString() {
        return bookingId + " - " + resource.getResourceName() + " - " + bookingDate + " (" + status + ")";
    }
}
