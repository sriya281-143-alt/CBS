## Demo login credentials

| Role    | Username | Password    |
|---------|----------|-------------|
| Student | aisha    | student123  |
| Student | james    | student123  |
| Staff   | rahul    | staff123    |
| Admin   | safir    | admin123    |

Role is detected automatically after login — Students/Staff land on the Resource
Listing page, Admins land on the Admin Dashboard.


- **Authentication** — `AuthService`/`AuthServiceImpl`, encoded (SHA-256, salted)
  password storage via `PasswordUtil`, real login validation in `LoginController`
  with an inline error message and role-based routing.
- **User hierarchy** — abstract `User` → `Student`, `Staff`, `Admin` (inheritance +
  polymorphism, matches the class diagram in the Part A report).
- **Resource hierarchy** — abstract `Resource` → `StudyRoom`, `LabEquipment`,
  `EventSpace`, managed through the generic `ResourceManager<T extends Resource>`.
- **Booking logic** — `BookingService`/`BookingServiceImpl` (acts as the design's
  `BookingManager`): validates duration (max 3 hours), prevents double-booking,
  auto-approves Staff/Admin bookings and routes Student bookings to PENDING for
  approval.
- **Custom exceptions** — `BookingException` (abstract) → `ResourceUnavailableException`,
  `InvalidBookingDurationException`, `UnauthorizedAccessException`, all shown to the
  user as inline error messages instead of stack traces.
- **File persistence** — `FileIOHandler` (generic `ObjectOutputStream`/`ObjectInputStream`
  serialization + text log appending), used by `AppContext` to load/seed data on
  startup and save everything on window close.
- **Logging** — `SystemLogger` + `LogEntry` record every login, booking, and resource
  change to `data/system_logs.txt`.
- **Working controllers** — `ResourcesController` (dynamic resource cards, search/filter,
  My Bookings table with cancel), `BookingController` (booking form + validation),
  `AdminDashboardController` (stats, pending-approval table with Approve/Reject,
  resource management table with Add/Edit/Delete).
- **Bug fixes** — corrected the login navigation path and the `fx:controller`
  mismatches in `booking.fxml` and `admin-dashboard.fxml`.

## OOP concept mapping (for your Part B report)

| Concept | Where |
|---|---|
| Abstraction | `User`, `Resource`, `BookingException` are abstract classes |
| Inheritance | `Student/Staff/Admin extends User`; `StudyRoom/LabEquipment/EventSpace extends Resource`; exception subclasses `extends BookingException` |
| Polymorphism | `getRole()`, `getResourceType()`, `checkAvailability()` behave differently per subclass; multi-catch on `BookingException` subtypes |
| Encapsulation | All model fields are `private` with controlled getters/setters |
| Generics | `ResourceManager<T extends Resource>` |
| Collections | `ArrayList`/`List` used throughout services and managers |
| Custom exceptions | `ResourceUnavailableException`, `InvalidBookingDurationException`, `UnauthorizedAccessException` |
| File I/O | `FileIOHandler` — `ObjectOutputStream`/`ObjectInputStream` for `.dat` files, `FileWriter`/`BufferedReader` for the text log |
| GUI/Event handling | JavaFX FXML + `@FXML` handlers across all four controllers |

